#!/usr/bin/env python3
import collections
import datetime
import json
import os
from pathlib import Path
import pwd
import re
import shlex
import shutil
import stat
import subprocess
import sys

class Incomplete(Exception):
    pass

def require(condition, message):
    if not condition:
        raise Incomplete(message)

def load(module, number):
    data = json.loads((module / "lesson.json").read_text(encoding="utf-8"))
    if (
        data["schema_version"] != 1
        or type(data["number"]) is not int
        or data["number"] != number
        or data["id"] != f"seminar-{number:02d}"
        or data["lab_dir"] != f"seminar{number}"
        or not re.fullmatch(r"\d+\.\d+\.\d+", data["version"])
    ):
        raise ValueError("Некорректные сведения о семинаре.")
    if not isinstance(data["title"], str) or not data["title"].strip():
        raise ValueError("Не задано название семинара.")
    if not isinstance(data["dependencies"], list):
        raise ValueError("dependencies должен быть списком.")
    if not all(isinstance(x, str) and x for x in data["dependencies"]):
        raise ValueError("Некорректный список зависимостей.")
    if not isinstance(data["tasks"], list) or not 1 <= len(data["tasks"]) <= 90:
        raise ValueError("Ожидается от 1 до 90 заданий.")
    seen = set()
    for item in data["tasks"]:
        if not re.fullmatch(f"s{number:02d}-[0-9]{{3}}", item["id"]):
            raise ValueError("Некорректный идентификатор задания.")
        if item["id"] in seen:
            raise ValueError("Идентификаторы заданий повторяются.")
        seen.add(item["id"])
        if item["mode"] not in ("auto", "manual"):
            raise ValueError("Неизвестный режим проверки.")
        for key in ("title", "expected"):
            if not isinstance(item[key], str) or not item[key].strip():
                raise ValueError(f"Некорректное поле {key}.")
        for key in ("instructions", "hint"):
            if (
                not isinstance(item[key], list) or not item[key]
                or not all(isinstance(x, str) for x in item[key])
            ):
                raise ValueError(f"Некорректное поле {key}.")
        for value in (
            item["id"], item["title"], item["expected"],
            *item["instructions"], *item["hint"]
        ):
            if "\0" in value or "\x1b" in value:
                raise ValueError("Управляющие символы в задании.")
    return data

def safe_file(path, boundary):
    try:
        relative = path.relative_to(boundary)
    except ValueError:
        raise Incomplete(f"Путь вне учебного каталога: {path}")
    require(not boundary.is_symlink(), f"Каталог является ссылкой: {boundary}")
    current = boundary
    for part in relative.parts:
        current = current / part
        require(not current.is_symlink(), f"Путь является ссылкой: {current}")
    try:
        mode = path.stat().st_mode
    except FileNotFoundError:
        raise Incomplete(f"Не найден файл: {path}")
    require(stat.S_ISREG(mode), f"Ожидается обычный файл: {path}")
    require(path.stat().st_size <= 20_000_000, f"Файл слишком большой: {path}")
    return path

def read(path, boundary):
    return safe_file(path, boundary).read_text(encoding="utf-8")

def same(actual, expected, boundary):
    require(
        safe_file(actual, boundary).read_bytes() == expected,
        f"Содержимое не соответствует заданию: {actual}"
    )

def installed(package):
    result = subprocess.run(
        ["dpkg-query", "-W", "-f=${Status}", package],
        text=True, capture_output=True
    )
    return (
        result.returncode == 0
        and result.stdout.strip().endswith(" ok installed")
    )

def values(text):
    result = {}
    for line in text.splitlines():
        require("=" in line, "Каждая строка отчёта должна иметь вид ключ=значение.")
        key, value = line.split("=", 1)
        require(key not in result, f"Ключ повторяется: {key}")
        result[key] = value
    return result

def os_name(text):
    for line in text.splitlines():
        if line.startswith("PRETTY_NAME="):
            parts = shlex.split(line.split("=", 1)[1])
            if len(parts) == 1:
                return parts[0]
    raise Incomplete("В system-info.txt не найден PRETTY_NAME.")

def events(text, batches):
    lines = text.splitlines()
    require(len(lines) == sum(batches), f"Ожидается {sum(batches)} событий.")
    offset = 0
    result = []
    for size in batches:
        for i in range(1, size + 1):
            fields = lines[offset].split("|")
            require(len(fields) == 5, f"Неверный формат события {offset + 1}.")
            timestamp, level, source, filename, status = fields
            try:
                parsed = datetime.datetime.fromisoformat(timestamp)
                valid_time = parsed.tzinfo is not None
            except ValueError:
                valid_time = False
            expected_level = "ERROR" if i % 10 == 0 else (
                "WARN" if i % 4 == 0 else "INFO"
            )
            require(
                valid_time
                and level == expected_level
                and source == ("sensor-a", "sensor-b", "sensor-c")[i % 3]
                and filename == f"event-{i:05d}.txt"
                and status == ("failed" if i % 10 == 0 else "accepted"),
                f"Событие {offset + 1} не соответствует запуску генератора."
            )
            result.append(fields)
            offset += 1
    return result

def counter_report(text):
    result = {}
    for line in text.splitlines():
        match = re.fullmatch(r"\s*(\d+)\s+(\S+)\s*", line)
        require(match is not None, "Нужен формат: количество пробел значение.")
        key = match.group(2)
        require(key not in result, f"Повторяется строка для {key}.")
        result[key] = int(match.group(1))
    return result

def prepare(module, lab):
    require(os.geteuid() != 0, "Подготавливай семинар без sudo.")
    require(lab == Path.home() / "seminar2", "Ожидается папка ~/seminar2.")
    require(not lab.is_symlink(), "Учебная папка является ссылкой.")
    require(not lab.exists() or lab.is_dir(), "seminar2 должен быть каталогом.")
    lab.mkdir(exist_ok=True)
    inputs = lab / ".inputs"
    require(not inputs.is_symlink(), ".inputs является ссылкой.")
    require(not inputs.exists() or inputs.is_dir(), ".inputs должен быть каталогом.")
    inputs.mkdir(exist_ok=True)

    def copy_once(src, dst):
        if dst.exists() or dst.is_symlink():
            safe_file(dst, lab)
            return
        shutil.copyfile(src, dst)
        dst.chmod(0o644)

    for name in ("seminar2-workbench.deb", "seminar2.md"):
        copy_once(module / "assets" / name, lab / name)

    previous = Path.home() / "seminar1/source"
    for name, fallback in (
        ("os-release.txt", Path("/etc/os-release")),
        ("users.txt", Path("/etc/passwd"))
    ):
        candidate = previous / name
        src = candidate if candidate.is_file() and not candidate.is_symlink() else fallback
        copy_once(src, inputs / name)

def check(module, lab, task_id):
    data = load(module, 2)
    item = next((x for x in data["tasks"] if x["id"] == task_id), None)
    if item is None or item["mode"] != "auto":
        raise ValueError("Неизвестное автоматическое задание.")
    n = int(task_id.rsplit("-", 1)[1])
    c = lab / "control-center"
    ref = module / "reference"
    login = pwd.getpwuid(os.getuid()).pw_name

    def text(relative):
        return read(c / relative, lab)

    def refbytes(relative):
        return (ref / relative).read_bytes()

    def tree():
        require(not lab.is_symlink(), "seminar2 является ссылкой.")
        require(not c.is_symlink(), "control-center является ссылкой.")
        for name in ("incoming", "processed", "logs", "config", "reports", "backup", "work"):
            path = c / name
            require(path.is_dir() and not path.is_symlink(), f"Нет обычного каталога: {path}")

    def active():
        return (
            (ref / "service.conf").read_text(encoding="utf-8")
            .replace("mode=dry-run", "mode=active")
            .replace("log_level=debug", "log_level=info")
            .replace("/tmp/seminar2/incoming", str(c / "incoming"))
            .replace("/tmp/seminar2/processed", str(c / "processed"))
        )

    def final_config():
        return active() + f"operator={login}\n# saved-with-vim\n"

    if n == 1:
        tree()
    elif n == 2:
        for target, source in (
            ("system-info.txt", "os-release.txt"),
            ("users.txt", "users.txt")
        ):
            same(c / "incoming" / target,
                 safe_file(lab / ".inputs" / source, lab).read_bytes(), lab)
    elif n == 3:
        expected = {
            "USER": login,
            "HOME": str(Path.home()),
            "SHELL": os.environ.get("SHELL", ""),
            "DISTRO": os_name(text("incoming/system-info.txt"))
        }
        require(values(text("reports/first-seminar.txt")) == expected,
                "Проверь четыре значения первого отчёта.")
    elif n in (5, 7):
        require(installed("tree"), "Пакет tree ещё не установлен.")
    elif n == 6:
        require(not installed("tree"), "Пакет tree всё ещё установлен.")
    elif n == 8:
        info = text("reports/package-info.txt")
        listing = text("reports/package-files.txt")
        for pattern in (
            r"(?m)^\s*Package:\s*seminar2-workbench\s*$",
            r"(?m)^\s*Version:\s*1\.0\s*$",
            r"(?m)^\s*Architecture:\s*all\s*$",
            r"(?m)^\s*Depends:.*tree.*tmux.*mc",
            r"(?m)^\s*Description:"
        ):
            require(re.search(pattern, info) is not None,
                    "В package-info.txt нужен полный вывод dpkg-deb --info.")
        for name in ("usr/bin/seminar2-generator",
                     "etc/seminar2-workbench/service.conf"):
            require(name in listing, f"В списке файлов нет {name}.")
    elif n in (9, 13):
        for name in ("seminar2-workbench", "tree", "tmux", "mc"):
            require(installed(name), f"Не установлен пакет {name}.")
        require(Path("/usr/bin/seminar2-generator").is_file(),
                "Не найден установленный генератор.")
        path = Path("/etc/seminar2-workbench/service.conf")
        require(path.is_file(), "Не найдена конфигурация стенда.")
        if n == 13:
            require(path.read_bytes() == refbytes("service.conf"),
                    "Исходная конфигурация стенда не восстановлена.")
    elif n == 11:
        require(not installed("seminar2-workbench"), "Стенд ещё установлен.")
        require(not Path("/usr/bin/seminar2-generator").exists(),
                "Программа генератора ещё присутствует.")
        require(Path("/etc/seminar2-workbench/service.conf").is_file(),
                "После remove конфигурация должна сохраниться.")
    elif n == 12:
        require(not installed("seminar2-workbench"), "Стенд ещё установлен.")
        path = Path("/etc/seminar2-workbench/service.conf")
        require(not path.exists() and not path.is_symlink(),
                "После purge конфигурация должна отсутствовать.")
    elif n == 14:
        same(c / "config/service.conf", refbytes("service.conf"), lab)
        for path in (ref / "data").iterdir():
            if path.is_file():
                same(c / "incoming" / path.name, path.read_bytes(), lab)
    elif n == 16:
        events(text("logs/events.log"), [40])
        same(c / "logs/events-first.log",
             safe_file(c / "logs/events.log", lab).read_bytes(), lab)
        diagnostic = text("logs/generator.err")
        require("error" in diagnostic.lower(), "В stderr нет диагностики ошибок.")
        same(c / "logs/generator-first.err",
             diagnostic.encode("utf-8"), lab)
        for i in range(1, 41):
            safe_file(c / f"incoming/event-{i:05d}.txt", lab)
    elif n in (17, 18):
        events(text("logs/events.log"), [40, 40] if n == 17 else [40, 40, 5000])
        first = text("logs/events-first.log")
        events(first, [40])
        require(text("logs/events.log").startswith(first),
                "Начало основного журнала отличается от первой копии.")
        first_error = text("logs/generator-first.err")
        require(bool(first_error), "Первая копия stderr пуста.")
        require(text("logs/generator.err").startswith(first_error),
                "Исходная диагностика была перезаписана.")
        require(len(text("logs/generator.err")) > len(first_error),
                "Диагностика второго запуска не добавлена.")
    elif n == 20:
        lines = text("logs/events.log").splitlines(keepends=True)
        require(len(lines) == 5080, "Основной журнал должен содержать 5080 событий.")
        require(text("reports/first-five.txt") == "".join(lines[:5]),
                "Неверные первые пять строк.")
        require(text("reports/last-ten.txt") == "".join(lines[-10:]),
                "Неверные последние десять строк.")
    elif n in (21, 22, 23, 27):
        rows = events(text("logs/events.log"), [40, 40, 5000])
        levels = collections.Counter(row[1] for row in rows)
        sources = collections.Counter(row[2] for row in rows)
        if n in (21, 22):
            filename = "levels.txt" if n == 21 else "sources.txt"
            expected = levels if n == 21 else sources
            require(counter_report(text("reports/" + filename)) == dict(expected),
                    "Счётчики не совпадают с журналом.")
        elif n == 23:
            actual = values(text("reports/event-summary.txt"))
            expected = {
                "total": str(len(rows)),
                **{k.lower(): str(v) for k, v in levels.items()},
                **{k: str(v) for k, v in sources.items()}
            }
            top = actual.pop("top_source", None)
            require(actual == expected, "Проверь поля и числа сводного отчёта.")
            require(top in sources and sources[top] == max(sources.values()),
                    "Неверно определён самый активный источник.")
        else:
            expected = "".join(
                line for line in text("logs/events.log").splitlines(keepends=True)
                if line.split("|")[1] == "ERROR"
            )
            require(text("reports/errors.log") == expected,
                    "В errors.log нужны все строки ERROR в исходном порядке.")
    elif n == 24:
        lines = text("logs/generator.err").splitlines()
        expected = {
            "diagnostics": str(len(lines)),
            "errors": str(sum("error" in line.lower() for line in lines))
        }
        require(values(text("reports/stderr-summary.txt")) == expected,
                "Счётчики stderr не совпадают с журналом.")
    elif n == 25:
        same(c / "config/service.conf", refbytes("service.conf"), lab)
        require(text("config/service-active.conf") == active(),
                "Проверь четыре преобразования конфигурации.")
    elif n in (26, 35):
        src = "incoming/event-00001.txt" if n == 26 else "incoming/live/event-00001.txt"
        dst = "processed/event-00001.txt" if n == 26 else "processed/live-sample.txt"
        original = text(src)
        require("status=accepted\n" in original,
                "В исходнике первого события ожидается status=accepted.")
        if n == 26:
            expected = "".join(
                line.replace("status=accepted", "status=processed")
                for line in original.splitlines(keepends=True)
                if not line.startswith("message=")
            )
        else:
            expected = original.replace("status=accepted", "status=processed")
        require(text(dst) == expected, "Обработанный файл не соответствует заданию.")
    elif n == 29:
        same(c / "config/service.conf", refbytes("service.conf"), lab)
        require(text("config/service-active.conf") == final_config(),
                "Проверь порядок строк, operator и комментарий после Vim.")
    elif n == 34:
        same(c / "backup/mc/input-01.txt", refbytes("data/input-01.txt"), lab)
        same(c / "processed/input-02-moved.txt", refbytes("data/input-02.txt"), lab)
        for name in ("input-01.txt", "input-02.txt"):
            same(c / "incoming" / name, refbytes("data/" + name), lab)
        moved = c / "work/input-02.txt"
        require(not moved.exists() and not moved.is_symlink(),
                "В work осталась копия, которую нужно было переместить.")
    elif n == 36:
        tree()
        require(text("config/service-active.conf") == final_config(),
                "Итоговая конфигурация изменилась.")
        for src, dst in (
            ("config/service-active.conf", "backup/final/service-active.conf"),
            ("reports/event-summary.txt", "backup/final/event-summary.txt"),
            ("reports/errors.log", "backup/final/errors.log")
        ):
            same(c / dst, safe_file(c / src, lab).read_bytes(), lab)
        same(lab / "seminar2-workbench.deb",
             (module / "assets/seminar2-workbench.deb").read_bytes(), lab)
        safe_file(c / "processed/live-sample.txt", lab)
    else:
        raise ValueError("Для этого задания проверка не реализована.")
    print("Результат задания подтверждён.")

def main():
    action = sys.argv[1]
    module = Path(sys.argv[2])
    if action == "load":
        data = load(module, int(sys.argv[3]))
        for item in data["tasks"]:
            fields = [
                item["id"], item["title"],
                f"Рабочая папка: ~/{data['lab_dir']}. Пути ниже — от неё.\n\n"
                + "\n".join(item["instructions"]),
                item["expected"],
                f"Сначала: cd ~/{data['lab_dir']}\n\n" + "\n".join(item["hint"]),
                item["mode"]
            ]
            for field in fields:
                sys.stdout.buffer.write(field.encode("utf-8") + b"\0")
    elif action == "setup":
        prepare(module, Path(sys.argv[3]))
    elif action == "check":
        check(module, Path(sys.argv[3]), sys.argv[4])
    else:
        raise ValueError("Неизвестное действие.")

try:
    main()
except Incomplete as exc:
    print(str(exc), file=sys.stderr)
    sys.exit(1)
except (OSError, ValueError, KeyError, IndexError, TypeError) as exc:
    print(f"Ошибка модуля семинара: {exc}", file=sys.stderr)
    sys.exit(2)
