#!/usr/bin/python3
import os
from pathlib import Path
import re
import subprocess
import sys

def main():
    arguments = sys.argv[1:]

    if arguments in (["--help"], ["-h"]):
        print("learn update — установить обновления Learn и семинаров")
        print("learn update --check — проверить без установки")
        return 0

    if arguments not in ([], ["--check"]):
        print("Используй learn update или learn update --check.",
              file=sys.stderr)
        return 2

    if os.environ.get("LEARN_ACTIVE") == "1":
        print("Сначала выйди из учебной оболочки командой exit.")
        print("Затем выполни learn update.")
        return 1

    source = Path("/etc/apt/sources.list.d/aledu.sources")
    key = Path("/usr/share/keyrings/aledu-archive-keyring.gpg")

    if not source.is_file() or not key.is_file():
        print("Команда обновления готова.")
        print("Источник обновлений Aledu пока не подключён.")
        print("Адрес публикации: https://rayvent.github.io/Aledu/")
        print("Следующий этап — подключение подписанного репозитория.")
        return 3

    packages = ["learn-course", "aledu-lessons"]

    query = subprocess.run(
        [
            "/usr/bin/dpkg-query", "-W",
            "-f=${binary:Package}\t${db:Status-Status}\n"
        ],
        text=True, capture_output=True, check=True
    )

    for line in query.stdout.splitlines():
        fields = line.split("\t")
        if len(fields) != 2:
            continue
        name, status = fields
        if (
            status == "installed"
            and re.fullmatch(
                r"learn-seminar-[0-9]{2}(?::[a-z0-9-]+)?",
                name
            )
        ):
            packages.append(name)

    packages = list(dict.fromkeys(packages))
    prefix = [] if os.geteuid() == 0 else ["/usr/bin/sudo"]

    print("Aledu Learn · Обновление", flush=True)
    print("1/2 · Получаем сведения о доступных пакетах…", flush=True)

    subprocess.run(
        prefix + [
            "/usr/bin/apt-get",
            "-o", "DPkg::Lock::Timeout=60",
            "update", "--error-on=any"
        ],
        check=True
    )

    checking = arguments == ["--check"]

    print(
        "2/2 · Проверяем доступные изменения…"
        if checking else
        "2/2 · Обновляем Learn и семинары…",
        flush=True
    )

    command = prefix + [
        "/usr/bin/apt-get",
        "-o", "DPkg::Lock::Timeout=60",
        "--no-remove"
    ]

    if checking:
        command.append("--simulate")

    command += ["install"] + packages
    subprocess.run(command, check=True)

    if checking:
        print("\nПроверка завершена. Установка не выполнялась.")
    else:
        version = subprocess.check_output(
            [
                "/usr/bin/dpkg-query", "-W",
                "-f=${Version}", "learn-course"
            ],
            text=True
        ).strip()
        print(f"\nОбновление завершено. Learn: {version}")
        print("Доступные семинары: learn list")

    return 0

try:
    sys.exit(main())
except subprocess.CalledProcessError as error:
    print(
        "\nОбновление не завершено. "
        "Причина указана в сообщении APT выше.",
        file=sys.stderr
    )
    sys.exit(error.returncode or 1)
except OSError as error:
    print(f"Не удалось запустить обновление: {error}", file=sys.stderr)
    sys.exit(1)
