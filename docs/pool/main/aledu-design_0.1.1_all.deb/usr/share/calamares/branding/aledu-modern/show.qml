import QtQuick 2.12

Rectangle {
    id: root
    color: "#193043"
    property int page: 0
    property var slides: [
        ["Практика начинается здесь", "Откройте Aledu Learn после установки.\nВыберите семинар и двигайтесь шаг за шагом."],
        ["Учитесь в своём темпе", "Задания, подсказки и проверка результата — рядом.\nПрогресс сохраняется между занятиями."],
        ["Пробуйте снова", "Начните семинар заново, когда захотите повторить.\nПредыдущая работа останется в архиве."]
    ]
    function onActivate() { rotation.start(); }
    function onLeave() { rotation.stop(); }
    Column {
        anchors.centerIn: parent
        width: Math.min(parent.width - 48, 600)
        spacing: 24
        Image { objectName: "aledu-slideshow-logo"; source: "logo.png"; width: 88; height: 88; anchors.horizontalCenter: parent.horizontalCenter; sourceSize.width: 176; sourceSize.height: 176 }
        Text { text: root.slides[root.page][0]; color: "#e7eff5"; font.pixelSize: 27; font.bold: true; width: parent.width; wrapMode: Text.WordWrap; horizontalAlignment: Text.AlignHCenter }
        Text { text: root.slides[root.page][1]; color: "#9cb3c5"; font.pixelSize: 16; width: parent.width; wrapMode: Text.WordWrap; horizontalAlignment: Text.AlignHCenter; lineHeight: 1.4 }
        Row {
            spacing: 8
            anchors.horizontalCenter: parent.horizontalCenter
            Repeater { model: 3; Rectangle { width: root.page === index ? 24 : 7; height: 7; radius: 3.5; color: root.page === index ? "#b6e5ee" : "#416279" } }
        }
    }
    Timer { id: rotation; interval: 9000; repeat: true; onTriggered: root.page = (root.page + 1) % root.slides.length }
}
