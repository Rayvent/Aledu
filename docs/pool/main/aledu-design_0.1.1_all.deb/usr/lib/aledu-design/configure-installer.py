#!/usr/bin/env python3
import argparse
from pathlib import Path
import shutil
import yaml

def configure(root):
    root = Path(root)
    base = root/'etc/calamares'
    settings_path = base/'settings.conf'
    if not settings_path.is_file():
        raise RuntimeError('Не найдены настройки установщика Debian.')
    def read(path):
        return yaml.safe_load(path.read_text())
    def write(path, value):
        path.parent.mkdir(parents=True,exist_ok=True)
        path.write_text(yaml.safe_dump(value,allow_unicode=True,sort_keys=False))
    settings = read(settings_path)
    sequence = settings['sequence']
    settings['branding'] = 'aledu-modern'
    write(settings_path,settings)
    users_path = base/'modules/users.conf'
    users = read(users_path)
    users['passwordRequirements'] = {'minLength':1,'maxLength':-1}
    # Preserve empty/mismatched-password checks; remove only strength requirements.
    users['doAutologin'] = False
    write(users_path,users)
    # Old hook-generated brand directory is searched before /usr/share.
    brand = root/'usr/share/calamares/branding/aledu-modern'
    override = base/'branding/aledu-modern'
    override.mkdir(parents=True,exist_ok=True)
    write(override/'branding.desc', read(brand/'branding.desc'))
    shutil.copyfile(brand/'stylesheet.qss',override/'stylesheet.qss')
    # Use absolute asset paths, so all search locations resolve the same files.
    assert read(settings_path)['sequence']==sequence
    assert read(users_path)['passwordRequirements']=={'minLength':1,'maxLength':-1}

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--root',default='/')
    args=parser.parse_args()
    configure(args.root)
    print('Дизайн установщика Aledu настроен; порядок установки сохранён.')
