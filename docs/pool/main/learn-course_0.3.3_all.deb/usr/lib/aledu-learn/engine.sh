#!/bin/bash
set -e

PROGRAM_VERSION="0.3.3"
script_dir="/usr/bin"
data_root="/usr/share/aledu-learn"
command_name="${1:-start}"

if [[ "$command_name" == "update" ]]; then
    shift
    exec /usr/bin/python3 /usr/lib/aledu-learn/update.py "$@"
fi

if [[ "$command_name" == "version" ]]; then
    printf 'learn %s\n' "$PROGRAM_VERSION"
    exit 0
fi

if [[ "$command_name" == "list" ]]; then
    printf '1 · Работа в терминале: основы\n'
    for manifest in "$data_root"/seminars/seminar-*/lesson.json; do
        [[ -f "$manifest" ]] || continue
        python3 - "$manifest" <<'LIST'
import json
import sys
with open(sys.argv[1], encoding="utf-8") as stream:
    data = json.load(stream)
print(f'{data["number"]} · {data["title"]}')
LIST
    done
    exit 0
fi

if (( $# > 2 )); then
    printf 'Пример: learn start 2\n' >&2
    exit 2
fi

seminar_number="${2:-${LEARN_SEMINAR:-1}}"
if [[ ! "$seminar_number" =~ ^[1-9][0-9]?$ ]]; then
    printf 'Укажи номер семинара от 1 до 99.\n' >&2
    exit 2
fi

if [[ "${LEARN_ACTIVE:-}" == "1" &&
      "$seminar_number" != "${LEARN_SEMINAR:-1}" ]]; then
    printf 'Сначала выйди из текущего семинара через exit.\n' >&2
    exit 1
fi

printf -v seminar_id 'seminar-%02d' "$seminar_number"
module_dir="$data_root/seminars/$seminar_id"

if (( seminar_number != 1 )) &&
   [[ ! -f "$module_dir/lesson.json" ]]; then
    printf 'Семинар %s не установлен. Доступные: learn list\n' \
        "$seminar_number" >&2
    exit 1
fi

if (( EUID == 0 )); then
    printf 'Запускай Learn обычным пользователем, без sudo.\n' >&2
    exit 1
fi

lab="$HOME/seminar$seminar_number"
archive_root="$HOME/seminar$seminar_number-archives"
state_dir="${XDG_STATE_HOME:-$HOME/.local/state}/learn/$seminar_id"
state_file="$state_dir/progress-v2"
if (( seminar_number != 1 )); then
    state_file="$state_dir/progress-id-v1"
fi

# ---------- Оформление ----------

C_RESET=""
C_BRAND=""
C_CYAN=""
C_GREEN=""
C_YELLOW=""
C_RED=""
C_DIM=""

UI_BOXES=0
UI_WIDTH=78
UI_INNER=74

init_ui() {
    local columns=80

    if [[ -t 1 && "${TERM:-dumb}" != "dumb" ]]; then
        UI_BOXES=1

        if command -v tput >/dev/null 2>&1; then
            columns="$(tput cols 2>/dev/null || printf '80')"
        fi

        [[ "$columns" =~ ^[0-9]+$ ]] || columns=80

        UI_WIDTH=$((columns - 2))

        if (( UI_WIDTH > 88 )); then
            UI_WIDTH=88
        fi

        if (( UI_WIDTH < 32 )); then
            UI_BOXES=0
            UI_WIDTH=78
        fi

        UI_INNER=$((UI_WIDTH - 4))

        if [[ -z "${NO_COLOR:-}" ]]; then
            C_RESET=$'\033[0m'
            C_BRAND=$'\033[1;35m'
            C_CYAN=$'\033[36m'
            C_GREEN=$'\033[32m'
            C_YELLOW=$'\033[33m'
            C_RED=$'\033[31m'
            C_DIM=$'\033[2m'
        fi
    fi

    return 0
}

ui_repeat() {
    local character="$1"
    local count="$2"
    local spaces=""

    if (( count <= 0 )); then
        return 0
    fi

    printf -v spaces '%*s' "$count" ""
    printf '%s' "${spaces// /$character}"
}

ui_row() {
    local color="$1"
    local text="$2"
    local padding=$((UI_INNER - ${#text}))

    if (( padding < 0 )); then
        padding=0
    fi

    printf '%s│%s %s' "$color" "$C_RESET" "$text"
    ui_repeat ' ' "$padding"
    printf ' %s│%s\n' "$color" "$C_RESET"
}

ui_wrap_line() {
    local color="$1"
    local line="$2"
    local piece=""
    local candidate=""

    line="${line//$'\t'/    }"

    while (( ${#line} > UI_INNER )); do
        piece="${line:0:UI_INNER}"

        if [[ "$piece" == *" "* ]]; then
            candidate="${piece% *}"

            if [[ -n "${candidate// /}" ]]; then
                piece="$candidate"
            fi
        fi

        ui_row "$color" "$piece"
        line="${line:${#piece}}"

        while [[ "$line" == " "* ]]; do
            line="${line# }"
        done
    done

    ui_row "$color" "$line"
    return 0
}

ui_box() {
    local color="$1"
    local title="$2"
    local body="${3:-}"
    local line=""
    local title_limit=$((UI_WIDTH - 6))
    local border_length

    if (( UI_BOXES == 0 )); then
        printf '\n[%s]\n%s\n' "$title" "$body"
        return 0
    fi

    if (( ${#title} > title_limit )); then
        title="${title:0:title_limit}…"
    fi

    border_length=$((UI_WIDTH - ${#title} - 5))

    printf '%s╭─ %s ' "$color" "$title"
    ui_repeat '─' "$border_length"
    printf '╮%s\n' "$C_RESET"

    while IFS= read -r line || [[ -n "$line" ]]; do
        ui_wrap_line "$color" "$line"
    done <<< "$body"

    printf '%s╰' "$color"
    ui_repeat '─' "$((UI_WIDTH - 2))"
    printf '╯%s\n' "$C_RESET"

    return 0
}

display_path() {
    local path="$1"

    if [[ "$path" == "$HOME" ]]; then
        printf '~'
    elif [[ "$path" == "$HOME/"* ]]; then
        printf '~/%s' "${path#"$HOME/"}"
    else
        printf '%s' "$path"
    fi
}

clear_screen() {
    if [[ -t 1 && "${TERM:-dumb}" != "dumb" ]]; then
        clear 2>/dev/null || true
    fi
}

init_ui

# ---------- Задания ----------

titles=()
tasks=()
hints=()
modes=()

add_task() {
    titles+=("$1")
    tasks+=("$2")
    hints+=("$3")
    modes+=("$4")
}

task_ids=()
if (( seminar_number == 1 )); then
add_task 'Поиск в руководстве' \
'1. Открой: man 1 ls
2. Нажми /, введи --help и нажми Enter.
3. Перейди между совпадениями клавишами n и Shift+N.
4. Закрой руководство клавишей q.' \
'Стрелки — прокрутка, / — поиск.
n — следующее совпадение, Shift+N — предыдущее.
q возвращает в командную строку.' \
manual

add_task 'Скрытые файлы' \
'1. Через man 1 ls найди параметр показа скрытых файлов.
2. Закрой руководство.
3. Выведи домашнюю папку с этим параметром.

Результат: видны имена, начинающиеся с точки.' \
'Найди в руководстве параметр -a.
Домашнюю папку можно указать как ~.' \
manual

add_task 'Подробный список' \
'1. Найди параметры ls для подробного вывода и удобных размеров.
2. Выведи домашнюю папку с обоими параметрами.
3. Найди параметр рекурсивного просмотра.
4. Примени его к ~/seminar1.' \
'Изучи параметры -l, -h и -R.
Параметры можно объединять: ls -lh ~.' \
manual

add_task 'Перемещение по системе' \
'1. Перейди домой и выполни pwd.
2. Перейди в / и посмотри его содержимое.
3. Вернись домой, затем перейди в родительский каталог.
4. Вернись в предыдущий каталог через cd -.' \
'cd без аргументов ведёт домой.
cd / — в корень, cd .. — в родительский каталог.
cd - возвращает в предыдущий каталог.
Точка . обозначает текущий каталог.' \
manual

add_task 'Рабочие каталоги' \
'Создай внутри ~/seminar1 четыре каталога:
source, backup, reports и tmp.

Результат: все четыре каталога существуют.' \
'Используй mkdir -p.
Можно передать несколько путей:
mkdir -p путь1 путь2 путь3' \
auto

add_task 'Просмотр другого каталога' \
'1. Перейди в ~/seminar1/source.
2. Через pwd проверь текущий путь.
3. Посмотри домашнюю папку, оставаясь в source.
4. Вернись домой одной командой.' \
'ls ~ показывает домашнюю папку без перехода.
Через pwd проверь, что каталог не изменился.
cd без аргументов возвращает домой.' \
manual

add_task 'Копирование файлов' \
'Скопируй два файла:

/etc/os-release → ~/seminar1/source/os-release.txt
/etc/passwd → ~/seminar1/source/users.txt

Результат: копии совпадают с оригиналами.' \
'Формат:
cp исходный_файл путь_к_копии

При копировании можно задать новое имя.' \
auto

add_task 'Вложенные каталоги' \
'1. Одной командой создай ~/seminar1/tmp/tree/level1/level2.
2. Внутри level2 создай пустые файлы a.txt, b.txt и c.txt.

Результат: три пустых файла находятся в level2.' \
'mkdir -p создаёт всю цепочку каталогов.
touch может создать несколько файлов одной командой.' \
auto

add_task 'Резервная копия дерева' \
'1. Скопируй tmp/tree целиком в ~/seminar1/backup.
2. Включи вывод выполняемых операций.
3. Скопируй source/os-release.txt в backup/os-release.txt.
4. Повтори копирование файла с запросом перезаписи и ответь n.

Все пути относятся к ~/seminar1.' \
'Для дерева используй cp -r, для вывода действий — -v.
Копируй tree в существующий каталог backup.
Для подтверждения перезаписи используй -i.' \
auto

add_task 'Изменение файлов' \
'В ~/seminar1/tmp/tree/level1/level2:

1. Переименуй a.txt в ready.txt.
2. Перемести b.txt в родительский каталог level1.
3. Удали c.txt с запросом подтверждения.' \
'mv переименовывает и перемещает файлы.
Родительский каталог обозначается ..
Удаление с подтверждением: rm -i путь_к_файлу' \
auto

add_task 'Удаление каталогов' \
'1. Создай ~/seminar1/tmp/delete-me/inner.
2. Удали дерево delete-me целиком.
3. Создай ~/seminar1/tmp/empty.
4. Удали empty через rmdir.

Остальные учебные файлы сохрани.' \
'mkdir -p создаёт вложенные каталоги.
Для удаления дерева изучи rm -r.
rmdir удаляет пустой каталог.' \
manual

add_task 'Два терминала' \
'1. Открой второе окно терминала.
2. В первом перейди в ~/seminar1/source.
3. Выполни pwd в обоих окнах.
4. В первом окне выполни tty.

Объясни, почему каталоги двух оболочек независимы.' \
'Каждая оболочка хранит свой текущий каталог.
tty показывает терминальное устройство сессии.' \
manual

add_task 'Вложенный Bash' \
'1. Перейди в ~/seminar1 и запусти bash.
2. Внутри него перейди в source.
3. Создай ../tmp/from-child-shell.txt.
4. Введи exit, затем проверь pwd.

Результат: файл остался, текущий каталог — ~/seminar1.' \
'Для создания пустого файла используй touch.
exit завершает один вложенный Bash.

Проверка подтвердит наличие файла.
Текущий каталог проверь самостоятельно через pwd.' \
auto

add_task 'Поиск пользователей' \
'В ~/seminar1/source/users.txt:

1. Найди строку пользователя root.
2. Найди строки с /bin/bash.
3. Повтори второй поиск с номерами строк.' \
'grep "^root:" файл ищет строку, начинающуюся с root:
Номера строк включает параметр -n.' \
manual

add_task 'Параметры grep' \
'1. В source/os-release.txt найди debian без учёта регистра.
2. Покажи строки этого файла без подстроки ID.
3. Посчитай строки с /bin/bash в source/users.txt.

Все пути относятся к ~/seminar1.' \
'В man grep найди:
-i — без учёта регистра
-v — строки без совпадения
-c — количество подходящих строк' \
manual

add_task 'Ввод с клавиатуры' \
'1. Запусти cat без имени файла.
2. Введи две строки текста.
3. На новой пустой строке нажми Ctrl+D.

Результат: cat завершился, снова видна командная строка.' \
'Без файла cat читает стандартный ввод.
Ctrl+D на пустой строке сообщает о конце ввода.' \
manual

add_task 'Запись и добавление' \
'Создай ~/seminar1/reports/summary.txt.

Первая строка:
Seminar 1 report

Через >> добавь ещё минимум две строки.' \
'Запись:
echo "текст" > файл

Добавление:
echo "ещё текст" >> файл' \
auto

add_task 'Сохранение поиска' \
'Найди строки с /bin/bash в ~/seminar1/source/users.txt.

Сохрани сами строки, без номеров, в:
~/seminar1/reports/bash-users.txt' \
'Направь вывод grep в файл через >
Параметры -n и -c здесь не нужны.' \
auto

add_task 'Вывод и ошибки' \
'1. Одной командой ls запроси:
   ~/seminar1/source и ~/seminar1/no-such-dir
2. Через > сохрани stdout в ~/seminar1/reports/listing.txt.

Результат: список — в отчёте, ошибка — в терминале.
Путь no-such-dir должен отсутствовать.' \
'После ls укажи два пути, затем > и путь отчёта.
Перенаправление > относится к stdout.
Ошибка идёт в stderr.' \
auto

add_task 'Переменные окружения' \
'1. Сохрани env в ~/seminar1/reports/environment.txt.
2. Выведи значения HOME, USER, SHELL и PATH.

Результат: отчёт содержит эти четыре переменные.' \
'env показывает переменные окружения.
Пример:
echo "$HOME"' \
auto

add_task 'Передача переменной' \
'1. Выполни unset SEMINAR, затем SEMINAR=first.
2. Запусти bash и проверь SEMINAR. Выйди через exit.
3. Выполни export SEMINAR и снова запусти bash.
4. Сохрани env в ~/seminar1/reports/environment-child.txt.
5. Выйди из вложенного Bash.' \
'export передаёт переменную дочерним программам.

В дочерней оболочке проверь:
echo "$SEMINAR"' \
auto

add_task 'Настройка Bash' \
'1. Найди упоминания COURSE в ~/.bashrc.
2. Если настройки ещё нет, добавь через >> строку:
   export COURSE="Operating Systems and Development Tools"
3. Запусти новый bash.
4. Сохрани env в ~/seminar1/reports/environment-bashrc.txt.
5. Выйди из вложенного Bash.' \
'Сначала проверь файл через grep.

Если настройки ещё нет, добавь её:
echo "export COURSE=\"Operating Systems and Development Tools\"" >> ~/.bashrc

Новый интерактивный Bash прочитает ~/.bashrc.' \
auto

add_task 'Копия отчётов' \
'1. Скопируй ~/seminar1/reports целиком в ~/seminar1/backup.
2. Включи вывод выполняемых операций.

Результат: backup/reports совпадает с reports.' \
'Используй cp с параметрами -r и -v.
Копируй reports в существующий backup.
Сравнение каталогов: diff -r.' \
auto

add_task 'Завершение семинара' \
'Очисти ~/seminar1/tmp, включая скрытые файлы.

Сохрани сам каталог tmp, а также source, reports и backup.

Результат: tmp существует и пуст, резервная копия сохранена.' \
'Посмотреть содержимое:
ls -A ~/seminar1/tmp

Очистка именно учебного tmp:
find ~/seminar1/tmp -mindepth 1 -delete

-mindepth 1 сохраняет сам каталог tmp.' \
auto

else
    import_file="$(mktemp)"
    if python3 "$data_root/lesson-tool.py" load \
        "$module_dir" "$seminar_number" > "$import_file"; then
        mapfile -d '' -t module_fields < "$import_file"
        rm -- "$import_file"
    else
        rm -- "$import_file"
        exit 2
    fi

    for ((i = 0; i < ${#module_fields[@]}; i += 6)); do
        task_ids+=("${module_fields[i]}")
        add_task \
            "${module_fields[i+1]}" \
            "${module_fields[i+2]}"$'\n\n'"Результат: ${module_fields[i+3]}" \
            "${module_fields[i+4]}" \
            "${module_fields[i+5]}"
    done
fi

prepare_lab() {
    if [[ -L "$lab" ]]; then
        fail "Учебная папка является ссылкой."
    fi
    if (( seminar_number == 1 )); then
        mkdir -p "$lab"
    else
        if ! bash "$module_dir/setup.sh" "$lab"; then
            fail "Не удалось подготовить материалы семинара."
        fi
    fi
}

total="${#titles[@]}"
step=1

# ---------- Прогресс и сообщения ----------

fail() {
    local heading="ОШИБКА"
    local body="$*"

    if [[ "$command_name" == "check" || "$command_name" == "done" ]]; then
        if [[ "${step:-}" =~ ^[1-9][0-9]?$ ]] &&
           (( step <= total )); then
            heading="ШАГ $step · НЕ ЗАВЕРШЁН"
            body="${titles[$((step - 1))]}"$'\n\n'"$body"
            body+=$'\n\n'"learn task — показать текущее задание"
            body+=$'\n'"learn hint — открыть подсказку"
        fi
    fi

    printf '\n' >&2
    ui_box "$C_RED" "✗ $heading" "$body" >&2
    printf '\n' >&2
    exit 1
}

mkdir -p "$state_dir"

if (( seminar_number == 1 )); then
if [[ -f "$state_file" ]]; then
    step="$(cat "$state_file")"
elif [[ -f "$state_dir/progress" ]]; then
    legacy="$(cat "$state_dir/progress")"

    case "$legacy" in
        1)  step=1  ;;
        2)  step=4  ;;
        3)  step=7  ;;
        4)  step=12 ;;
        5)  step=14 ;;
        6)  step=16 ;;
        7)  step=20 ;;
        8)  step=22 ;;
        9)  step=23 ;;
        10) step=25 ;;
        *) fail "Не удалось прочитать старый прогресс." ;;
    esac
fi

else
    if [[ -f "$state_file" ]]; then
        saved_id="$(cat "$state_file")"
        if ! saved_id="$(python3 /usr/lib/aledu-learn/lesson_progress.py "$module_dir" "$saved_id")"; then
            fail "Не удалось прочитать карту обновления заданий."
        fi
        if [[ "$saved_id" == "complete" ]]; then
            step=$((total + 1))
        else
            found=0
            for ((i = 0; i < total; i++)); do
                if [[ "${task_ids[i]}" == "$saved_id" ]]; then
                    step=$((i + 1))
                    found=1
                    break
                fi
            done
            (( found == 1 )) ||
                fail "Сохранённое задание не найдено в установленном семинаре."
        fi
    fi
fi

[[ "$step" =~ ^[1-9][0-9]?$ ]] \
    || fail "Некорректный файл прогресса: $state_file"

(( step <= total + 1 )) \
    || fail "Номер задания выходит за пределы семинара."

save_progress() {
    local value="$step"
    local temporary
    if (( seminar_number != 1 )); then
        if (( step > total )); then
            value="complete"
        else
            value="${task_ids[step-1]}"
        fi
    fi
    temporary="$(mktemp "$state_dir/.progress.XXXXXXXX")"
    printf '%s\n' "$value" > "$temporary"
    mv -- "$temporary" "$state_file"
}

show_header() {
    local completed=$((step - 1))
    local percent
    local filled
    local bar
    local body
    local status

    if (( completed > total )); then
        completed="$total"
    fi

    percent=$((completed * 100 / total))
    filled=$((completed * 16 / total))

    bar="$(ui_repeat '█' "$filled")"
    bar+="$(ui_repeat '░' "$((16 - filled))")"

    if (( step > total )); then
        status="Семинар $seminar_number · Завершён"
    else
        status="Семинар $seminar_number · Шаг $step / $total"
    fi

    printf -v body '%s\n%s  %s%% · Пройдено %s/%s' \
        "$status" "$bar" "$percent" "$completed" "$total"

    ui_box "$C_BRAND" "ALEDU LEARN" "$body"
}

need_dir() {
    [[ -d "$1" ]] \
        || fail "Не найден каталог: $(display_path "$1")"
}

need_file() {
    [[ -f "$1" ]] \
        || fail "Не найден файл: $(display_path "$1")"
}

need_empty_file() {
    need_file "$1"

    [[ ! -s "$1" ]] \
        || fail "Файл должен быть пустым: $(display_path "$1")"
}

need_absent() {
    [[ ! -e "$1" && ! -L "$1" ]] \
        || fail "Этот путь должен отсутствовать: $(display_path "$1")"
}

# ---------- Экраны курса ----------

show_task() {
    show_header
    printf '\n'

    if (( step > total )); then
        ui_box "$C_GREEN" "✓ СЕМИНАР ЗАВЕРШЁН" \
            "Все $total шагов пройдены.
learn menu — открыть итоговое меню"
        printf '\n'
        return 0
    fi

    local index=$((step - 1))
    local commands

    ui_box "$C_CYAN" \
        "ЗАДАНИЕ · ${titles[$index]}" \
        "${tasks[$index]}"

    printf '\n'

    if [[ "${modes[$index]}" == "manual" ]]; then
        commands="learn done — отметить выполнение"
    else
        commands="learn check — проверить результат"
    fi

    commands+="   |   learn hint — подсказка"
    commands+=$'\n'"learn task — задание   |   learn menu — главное меню"
    commands+=$'\n'"exit — вернуться в главное меню"

    ui_box "$C_DIM" "КОМАНДЫ" "$commands"
    printf '\n'

    return 0
}

show_hint() {
    if (( step > total )); then
        ui_box "$C_YELLOW" "ПОДСКАЗКА" \
            "Семинар уже завершён.
learn menu — открыть итоговое меню"
        printf '\n'
        return 0
    fi

    local index=$((step - 1))

    printf '\n'
    ui_box "$C_YELLOW" \
        "ПОДСКАЗКА · ШАГ $step" \
        "${hints[$index]}"
    printf '\n'
}

show_status() {
    printf '\n'
    show_header

    if (( step <= total )); then
        printf '\n'
        ui_box "$C_CYAN" "ТЕКУЩЕЕ ЗАДАНИЕ" \
            "${titles[$((step - 1))]}
Учебная папка: $(display_path "$lab")"
    fi

    printf '\n'
}

show_results() {
    local completed=$((step - 1))
    local index
    local method
    local line
    local body=""
    local files

    clear_screen
    show_header
    printf '\n'

    for ((index = 0; index < completed; index++)); do
        if [[ "${modes[$index]}" == "manual" ]]; then
            method="самопроверка"
        else
            method="проверка файлов"
        fi

        printf -v line '✓ %2d. %s — %s' \
            "$((index + 1))" "${titles[$index]}" "$method"

        body+="$line"$'\n'
    done

    if [[ -z "$body" ]]; then
        body="Завершённых шагов пока нет."
    fi

    ui_box "$C_GREEN" "РЕЗУЛЬТАТЫ" "${body%$'\n'}"
    printf '\n'

    files="Учебные файлы: $(display_path "$lab")"

    if [[ -d "$lab/reports" ]]; then
        files+=$'\n\n'"Отчёты:"
        files+=$'\n'"$(ls -1 -- "$lab/reports")"
    fi

    ui_box "$C_CYAN" "ФАЙЛЫ" "$files"
    printf '\n'

    ui_box "$C_DIM" "О ПРОВЕРКАХ" \
        "Проверки файлов подтверждают результат работы.
Знание параметров команд обсуждается с преподавателем."
    printf '\n'
}

repeat_seminar() {
    local archive=""

    if [[ -L "$lab" ]]; then
        fail "Учебная папка является ссылкой. Повторный запуск остановлен."
    fi

    if [[ -e "$lab" ]]; then
        need_dir "$lab"
        mkdir -p "$archive_root"

        archive="$(mktemp -d \
            "$archive_root/attempt-$(date +%Y%m%d-%H%M%S)-XXXXXX")"

        mv -- "$lab" "$archive/seminar$seminar_number"
    fi

    prepare_lab
    step=1
    save_progress

    clear_screen

    if [[ -n "$archive" ]]; then
        ui_box "$C_GREEN" "✓ ПРОШЛАЯ ПОПЫТКА СОХРАНЕНА" \
            "$(display_path "$archive/seminar$seminar_number")"
        printf '\n'
    fi

    show_task
}

finish_menu() {
    local choice
    local answer

    menu_action="exit"

    while true; do
        clear_screen
        show_header
        printf '\n'

        ui_box "$C_GREEN" "✓ СЕМИНАР ЗАВЕРШЁН" \
            "1. Посмотреть результаты
2. Пройти заново — сохранить прошлую попытку в архив
3. Следующий семинар
4. Выйти"

        printf '\n%sВыбор [1–4]: %s' "$C_CYAN" "$C_RESET"

        if ! IFS= read -r choice; then
            printf '\n'
            return 0
        fi

        case "$choice" in
            1)
                show_results

                if ! IFS= read -r -p \
                    'Enter — вернуться к меню: ' answer; then
                    return 0
                fi
                ;;
            2)
                if [[ "${LEARN_FRONTEND:-}" == "1" ]]; then
                    menu_action="restart"
                    return 0
                fi
                repeat_seminar
                menu_action="restart"
                return 0
                ;;
            3)
                local next_id
                printf -v next_id 'seminar-%02d' "$((seminar_number + 1))"
                if [[ -f "$data_root/seminars/$next_id/lesson.json" ]]; then
                    menu_action="next"
                    return 0
                fi
                printf '\n'
                ui_box "$C_YELLOW" "СЛЕДУЮЩИЙ СЕМИНАР" \
                    "Следующий семинар пока не установлен."
                printf '\n'

                if ! IFS= read -r -p \
                    'Enter — вернуться к меню: ' answer; then
                    return 0
                fi
                ;;
            4)
                return 0
                ;;
            *)
                printf '\n'
                ui_box "$C_RED" "✗ НЕВЕРНЫЙ ВЫБОР" \
                    "Введи число от 1 до 4."
                printf '\n'

                if ! IFS= read -r -p \
                    'Enter — повторить выбор: ' answer; then
                    return 0
                fi
                ;;
        esac
    done
}

handle_completion() {
    finish_menu

    if [[ "$menu_action" == "next" ]]; then
        if [[ "${LEARN_ACTIVE:-}" == "1" ]]; then
            exit 44
        fi
        exec "$script_dir/learn" start "$((seminar_number + 1))"
    fi

    if [[ "$menu_action" == "restart" ]]; then
        if [[ "${LEARN_FRONTEND:-}" == "1" ]]; then
            exec "$script_dir/learn" restart "$seminar_number"
        fi
        if [[ "${LEARN_ACTIVE:-}" == "1" ]]; then
            exit 43
        fi

        start_session start "$seminar_number"
        return 0
    fi

    if [[ "${LEARN_ACTIVE:-}" == "1" ]]; then
        exit 42
    fi

    exit 0
}

advance() {
    local message="$1"

    step=$((step + 1))
    save_progress

    if (( step > total )); then
        handle_completion
        return 0
    fi

    clear_screen
    ui_box "$C_GREEN" "✓ ГОТОВО" "$message"
    printf '\n'
    show_task
}

# ---------- Проверки заданий ----------

check_task() {
    if (( step > total )); then
        handle_completion
        return 0
    fi

    local index=$((step - 1))
    local name
    local first_line
    local remaining

    if [[ "${modes[$index]}" == "manual" ]]; then
        printf '\n'
        ui_box "$C_YELLOW" "САМОПРОВЕРКА · ШАГ $step" \
            "Этот шаг проверяется самостоятельно.
После выполнения введи learn done."
        printf '\n'
        return 0
    fi

    if (( seminar_number != 1 )); then
        local result message
        if message="$(bash "$module_dir/check.sh" \
            "$lab" "${task_ids[index]}" 2>&1)"; then
            advance "Результат шага $step проверен."
            return 0
        else
            result=$?
        fi
        if (( result == 1 )); then
            fail "$message"
        fi
        ui_box "$C_RED" "ОШИБКА ПРОВЕРКИ" "$message" >&2
        exit 2
    fi

    case "$step" in
        5)
            for name in source backup reports tmp; do
                need_dir "$lab/$name"
            done
            ;;

        7)
            need_file "$lab/source/os-release.txt"
            need_file "$lab/source/users.txt"

            cmp -s /etc/os-release "$lab/source/os-release.txt" \
                || fail "os-release.txt отличается от /etc/os-release."

            cmp -s /etc/passwd "$lab/source/users.txt" \
                || fail "users.txt отличается от /etc/passwd."
            ;;

        8)
            need_dir "$lab/tmp/tree/level1/level2"

            for name in a.txt b.txt c.txt; do
                need_empty_file "$lab/tmp/tree/level1/level2/$name"
            done
            ;;

        9)
            if [[ ! -d "$lab/backup/tree/level1/level2" ]]; then
                fail "Дерево ещё не скопировано в backup.

Скопируй ~/seminar1/tmp/tree в ~/seminar1/backup/."
            fi

            for name in a.txt b.txt c.txt; do
                need_empty_file "$lab/backup/tree/level1/level2/$name"
            done

            need_file "$lab/source/os-release.txt"
            need_file "$lab/backup/os-release.txt"

            cmp -s "$lab/source/os-release.txt" \
                "$lab/backup/os-release.txt" \
                || fail "Копия backup/os-release.txt отличается от source/os-release.txt."
            ;;

        10)
            need_empty_file "$lab/tmp/tree/level1/level2/ready.txt"
            need_empty_file "$lab/tmp/tree/level1/b.txt"

            for name in a.txt b.txt c.txt; do
                need_absent "$lab/tmp/tree/level1/level2/$name"
            done
            ;;

        13)
            need_file "$lab/tmp/from-child-shell.txt"
            ;;

        17)
            need_file "$lab/reports/summary.txt"

            first_line=""
            IFS= read -r first_line \
                < "$lab/reports/summary.txt" || true

            [[ "$first_line" == "Seminar 1 report" ]] \
                || fail "Первая строка должна быть: Seminar 1 report"

            [[ "$(wc -l < "$lab/reports/summary.txt")" -ge 3 ]] \
                || fail "Добавь минимум две строки после заголовка."
            ;;

        18)
            need_file "$lab/source/users.txt"
            need_file "$lab/reports/bash-users.txt"

            cmp -s "$lab/reports/bash-users.txt" \
                <(grep -F '/bin/bash' "$lab/source/users.txt" || true) \
                || fail "В отчёте нужны строки с /bin/bash без номеров."
            ;;

        19)
            need_absent "$lab/no-such-dir"
            need_file "$lab/reports/listing.txt"

            grep -Fq 'os-release.txt' "$lab/reports/listing.txt" \
                || fail "В listing.txt нет имени os-release.txt."

            grep -Fq 'users.txt' "$lab/reports/listing.txt" \
                || fail "В listing.txt нет имени users.txt."

            if grep -Fq 'no-such-dir' "$lab/reports/listing.txt"; then
                fail "В отчёт попала ошибка. Перенаправь только stdout."
            fi
            ;;

        20)
            need_file "$lab/reports/environment.txt"

            for name in HOME USER SHELL PATH; do
                grep -q "^${name}=" "$lab/reports/environment.txt" \
                    || fail "В отчёте нет переменной $name."
            done
            ;;

        21)
            need_file "$lab/reports/environment-child.txt"

            grep -Fxq 'SEMINAR=first' \
                "$lab/reports/environment-child.txt" \
                || fail "В окружении дочернего Bash нет SEMINAR=first."
            ;;

        22)
            need_file "$HOME/.bashrc"
            need_file "$lab/reports/environment-bashrc.txt"

            grep -Fxq \
                'COURSE=Operating Systems and Development Tools' \
                "$lab/reports/environment-bashrc.txt" \
                || fail "В отчёте нет экспортированной переменной COURSE."

            if ! env -u COURSE bash -ic \
                'env | grep -Fxq "COURSE=Operating Systems and Development Tools"' \
                >/dev/null 2>&1; then
                fail "Новый Bash не получает COURSE из настройки."
            fi
            ;;

        23)
            need_dir "$lab/reports"
            need_dir "$lab/backup/reports"

            for name in \
                summary.txt \
                bash-users.txt \
                listing.txt \
                environment.txt \
                environment-child.txt \
                environment-bashrc.txt
            do
                need_file "$lab/reports/$name"
            done

            diff -qr "$lab/reports" "$lab/backup/reports" \
                >/dev/null \
                || fail "Копия backup/reports отличается от reports."
            ;;

        24)
            need_dir "$lab/source"
            need_dir "$lab/reports"
            need_dir "$lab/backup/reports"
            need_dir "$lab/tmp"

            remaining="$(find "$lab/tmp" -mindepth 1 -print -quit)" \
                || fail "Не удалось проверить содержимое tmp."

            [[ -z "$remaining" ]] \
                || fail "В tmp ещё остались файлы или каталоги."

            diff -qr "$lab/reports" "$lab/backup/reports" \
                >/dev/null \
                || fail "Резервная копия отчётов отличается."
            ;;
    esac

    advance "Результат шага $step проверен."
}

mark_done() {
    if (( step > total )); then
        handle_completion
        return 0
    fi

    local index=$((step - 1))

    [[ "${modes[$index]}" == "manual" ]] \
        || fail "Для этого шага используй learn check."

    advance "Шаг $step отмечен тобой как выполненный."
}

# ---------- Учебная оболочка ----------

prepare_session_rc() {
    cat > "$state_dir/session.bashrc" <<'RC'
set +e

if [[ -r "$HOME/.bashrc" ]]; then
    source "$HOME/.bashrc"
fi

set +e
export PATH="$LEARN_BIN:$PATH"

if [[ -t 1 &&
      "${TERM:-dumb}" != "dumb" &&
      -z "${NO_COLOR:-}" ]]; then
    PS1='\[\e[1;35m\][ALEDU LEARN]\[\e[0m\] \[\e[36m\]\w\[\e[0m\] \$ '
else
    PS1='[ALEDU LEARN] \w\$ '
fi

learn() {
    local result

    if "$LEARN_EXEC" "$@"; then
        return 0
    else
        result=$?
    fi

    case "$result" in
        42)
            exit 0
            ;;
        43)
            builtin cd -- "$LEARN_LAB" || return 1
            return 0
            ;;
        44)
            exec env -u LEARN_ACTIVE -u LEARN_SEMINAR \
                "$LEARN_EXEC" start "$((LEARN_SEMINAR + 1))"
            ;;
        *)
            return "$result"
            ;;
    esac
}

export -f learn
RC
}

start_session() {
    [[ "${2:-$seminar_number}" == "$seminar_number" ]] \
        || fail "Неверный номер семинара."

    if (( step > total )); then
        handle_completion
        return 0
    fi

    # Повторный start внутри курса не создаёт новую оболочку.
    if [[ "${LEARN_ACTIVE:-}" == "1" ]]; then
        clear_screen
        show_task
        return 0
    fi

    prepare_lab
    save_progress
    prepare_session_rc

    clear_screen
    show_task

    cd "$lab"

    export LEARN_SEMINAR="$seminar_number"
    export LEARN_SESSION_PID="$$"
    export LEARN_ACTIVE=1
    export LEARN_EXEC="$script_dir/learn"
    export LEARN_LAB="$lab"
    export LEARN_BIN="$script_dir"
    export PATH="$script_dir:$PATH"

    exec bash --rcfile "$state_dir/session.bashrc" -i
}

# ---------- Команды ----------

case "$command_name" in
    start)
        start_session "$@"
        ;;
    task)
        if (( step > total )); then
            handle_completion
        else
            clear_screen
            show_task
        fi
        ;;
    hint)
        show_hint
        ;;
    check)
        check_task
        ;;
    done)
        mark_done
        ;;
    status)
        show_status
        ;;
    results)
        show_results
        ;;
    menu)
        if (( step <= total )); then
            fail "Финальное меню появится после завершения семинара."
        fi

        handle_completion
        ;;
    version)
        printf 'learn %s\n' "$PROGRAM_VERSION"
        ;;
    *)
        ui_box "$C_BRAND" "КОМАНДЫ LEARN" \
            "learn start НОМЕР
learn list
learn update | learn update --check
learn task | hint | check | done | status
learn results | menu | version"
        exit 1
        ;;
esac
