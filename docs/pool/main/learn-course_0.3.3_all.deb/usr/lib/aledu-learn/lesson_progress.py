#!/usr/bin/python3
"""Resolve retired task IDs without changing the user's stored progress."""
import json
from pathlib import Path
import re
import sys


def resolve_progress(module, value):
    module = Path(module)
    mapping = module/'progress-map.json'
    if not mapping.exists():
        return value
    manifest = json.loads((module/'lesson.json').read_text(encoding='utf-8'))
    ids = {task['id'] for task in manifest['tasks']}
    aliases = json.loads(mapping.read_text(encoding='utf-8'))
    prefix = f"s{manifest['number']:02}-"
    if not isinstance(aliases,dict) or not all(
        isinstance(old,str) and re.fullmatch(re.escape(prefix)+r'[0-9]{3}',old)
        and old not in ids and isinstance(new,str) and new in ids
        for old,new in aliases.items()
    ):
        raise ValueError('Некорректная карта обновления заданий.')
    return aliases.get(value,value)


if __name__=='__main__':
    try:
        if len(sys.argv)!=3:
            raise ValueError('Ожидались каталог семинара и сохранённый ID.')
        print(resolve_progress(sys.argv[1],sys.argv[2]))
    except (OSError,ValueError,KeyError,TypeError) as error:
        print(f'Не удалось прочитать прогресс: {error}',file=sys.stderr)
        sys.exit(2)
