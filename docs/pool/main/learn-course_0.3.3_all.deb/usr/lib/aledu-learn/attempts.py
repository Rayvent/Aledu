"""Archive a learning attempt, including local Git links, before resetting progress."""
import datetime
import os
from pathlib import Path
import shutil
import subprocess
import tempfile


def git(repo,*arguments):
    executable = '/usr/bin/git' if os.name!='nt' else shutil.which('git')
    if not executable:
        raise ValueError('Для сохранения учебного Git-репозитория нужен установленный git.')
    env = {k:v for k,v in os.environ.items() if not k.startswith('GIT_')}
    env.update(GIT_CONFIG_NOSYSTEM='1',GIT_CONFIG_GLOBAL=os.devnull,
               GIT_OPTIONAL_LOCKS='0',GIT_NO_LAZY_FETCH='1')
    command = [executable,'--no-pager',f'--git-dir={repo / ".git"}',f'--work-tree={repo}',
               '-c',f'core.hooksPath={os.devnull}','-c','core.fsmonitor=false',
               '-c','gc.auto=0','-c','maintenance.auto=false',*arguments]
    result = subprocess.run(command,env=env,capture_output=True,timeout=30)
    if result.returncode:
        raise ValueError(f'Не удалось сохранить связи Git в {repo.name}. Исходные файлы сохранены.')
    return result.stdout


def relocation_plan(lab):
    if not lab.exists():
        return []
    plan = []
    boundary = lab.resolve()
    for parent,dirs,files in os.walk(lab,followlinks=False):
        repo = Path(parent)
        # A bare server has no working-tree paths to fix.
        if (repo/'HEAD').is_file() and (repo/'objects').is_dir() and (repo/'config').is_file():
            dirs[:] = []
            continue
        if '.git' not in dirs:
            continue
        dirs.remove('.git')
        if (repo/'.git').is_symlink() or (repo/'.git/config').is_symlink():
            raise ValueError('Повтор остановлен: служебная папка Git является ссылкой.')
        linked = []
        for block in git(repo,'worktree','list','--porcelain','-z').split(b'\0\0'):
            fields = dict(line.decode().split(' ',1) for line in block.split(b'\0') if b' ' in line)
            if 'worktree' not in fields:
                continue
            worktree = Path(fields['worktree']).resolve()
            try:
                relative = worktree.relative_to(boundary)
            except ValueError:
                raise ValueError('Дополнительное дерево Git находится вне учебной папки. '
                                 'Заверши работу с ним перед повтором семинара.') from None
            if not worktree.is_dir():
                raise ValueError('В Git осталось отсутствующее рабочее дерево. '
                                 'Проверь git worktree list и убери устаревшую запись перед повтором.')
            if worktree!=repo.resolve():
                linked.append(relative)
        remotes = []
        for record in git(repo,'config','--local','--null','--list').split(b'\0'):
            if b'\n' not in record:
                continue
            key,value = record.decode().split('\n',1)
            if not (key.startswith('remote.') and key.endswith('.url')):
                continue
            candidate = Path(value)
            if candidate.is_absolute():
                try:
                    relative = candidate.resolve().relative_to(boundary)
                except ValueError:
                    continue
                remotes.append((key,relative))
        if linked or remotes:
            plan.append((repo.relative_to(lab),linked,remotes))
    return plan


def repair(plan,source,destination):
    for relative,linked,remotes in plan:
        repo = destination/relative
        if linked:
            git(repo,'worktree','repair',*[str(destination/path) for path in linked])
        for key,path in remotes:
            old,new = str(source/path),str(destination/path)
            values = git(repo,'config','--local','--get-all',key).decode().splitlines()
            matches = [v for v in values if Path(v).is_absolute() and Path(v).resolve()==Path(old).resolve()]
            if matches:
                for value in matches:
                    git(repo,'config','--local','--fixed-value','--replace-all',key,new,value)
            elif not any(Path(v).is_absolute() and Path(v).resolve()==Path(new).resolve() for v in values):
                raise ValueError('Адрес учебного Git-сервера изменился во время сохранения попытки.')


def archive_attempt(lab,folder,archive_root,filename,first,atomic_write):
    for path in (lab,folder,archive_root):
        if path.is_symlink() or (path.exists() and not path.is_dir()):
            raise ValueError(f'Повтор остановлен: ожидался обычный каталог {path}.')
    plan = relocation_plan(lab)
    archive_root.mkdir(parents=True,exist_ok=True)
    archive = Path(tempfile.mkdtemp(prefix='attempt-'+datetime.datetime.now().strftime('%Y%m%d-%H%M%S-'),dir=archive_root))
    if folder.is_dir():
        shutil.copytree(folder,archive/'progress',symlinks=True)
    moved = False
    try:
        if lab.exists():
            lab.rename(archive/lab.name)
            moved = True
            repair(plan,lab,archive/lab.name)
        atomic_write(folder/filename,first+'\n')
    except Exception:
        if moved:
            archived = archive/lab.name
            archived.rename(lab)
            repair(plan,archived,lab)
        raise
    return archive
