#!/usr/bin/python3
import datetime
import json
import os
from pathlib import Path
import re
import shutil
import signal
import subprocess
import sys
import tempfile
from lesson_progress import resolve_progress
from attempts import archive_attempt
import textwrap

ENGINE = Path("/usr/lib/aledu-learn/engine.sh")
DATA = Path("/usr/share/aledu-learn/seminars")
HOME = Path.home()
STATE = Path(os.environ.get(
    "XDG_STATE_HOME", str(HOME / ".local/state")
)) / "learn"

TTY = sys.stdout.isatty() and os.environ.get("TERM", "dumb") != "dumb"
COLOR = TTY and not os.environ.get("NO_COLOR")

PURPLE = "\033[1;35m" if COLOR else ""
CYAN = "\033[36m" if COLOR else ""
GREEN = "\033[32m" if COLOR else ""
YELLOW = "\033[33m" if COLOR else ""
RESET = "\033[0m" if COLOR else ""

def clean_env():
    env = os.environ.copy()
    for key in (
        "LEARN_ACTIVE", "LEARN_SEMINAR", "LEARN_EXEC",
        "LEARN_BIN", "LEARN_LAB", "LEARN_SESSION_PID",
        "LEARN_FRONTEND", "LEARN_MENU_PID", "LEARN_REQUEST_FILE",
        "BASH_FUNC_learn%%"
    ):
        env.pop(key, None)
    return env

def clear():
    if TTY:
        print("\033[2J\033[H", end="", flush=True)

def box(title, body, color=CYAN):
    width = min(88, max(40, shutil.get_terminal_size((80, 24)).columns - 2))
    inner = width - 4
    title = title[:width - 7]
    print(color + "╭─ " + title + " " + "─" * (width - len(title) - 5) + "╮" + RESET)
    for line in str(body).splitlines():
        pieces = textwrap.wrap(
            line, width=inner, replace_whitespace=False
        ) or [""]
        for piece in pieces:
            print(color + "│" + RESET + " " + piece.ljust(inner)
                  + " " + color + "│" + RESET)
    print(color + "╰" + "─" * (width - 2) + "╯" + RESET)

def pause():
    try:
        input("\nEnter — продолжить: ")
    except EOFError:
        pass

def ask(prompt):
    try:
        return input(prompt).strip()
    except EOFError:
        return None

def atomic_write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.is_symlink():
        raise ValueError(f"Нельзя записывать через ссылку: {path}")
    with tempfile.NamedTemporaryFile(
        mode="w", encoding="utf-8",
        dir=path.parent, prefix=".learn-", delete=False
    ) as stream:
        temporary = Path(stream.name)
        stream.write(value)
    os.replace(temporary, path)

def courses():
    result = [{
        "number": 1,
        "title": "Работа в терминале: основы",
        "ids": [str(i) for i in range(1, 25)],
        "legacy": True,
    }]
    for manifest in sorted(DATA.glob("seminar-*/lesson.json")):
        try:
            data = json.loads(manifest.read_text(encoding="utf-8"))
            number = data["number"]
            ids = [item["id"] for item in data["tasks"]]
            if (
                type(number) is not int or not 2 <= number <= 99
                or data["id"] != f"seminar-{number:02d}"
                or data["lab_dir"] != f"seminar{number}"
                or not 1 <= len(ids) <= 90
                or not all(isinstance(x, str) and x for x in ids)
                or len(set(ids)) != len(ids)
                or not isinstance(data["title"], str)
            ):
                continue
            result.append({
                "number": number,
                "title": re.sub(r"[\x00-\x1f\x7f]", "", data["title"]),
                "ids": ids,
                "module": str(manifest.parent),
                "legacy": False,
            })
        except (OSError, ValueError, KeyError, TypeError):
            continue
    return sorted(result, key=lambda item: item["number"])

def course_by(number):
    for course in courses():
        if course["number"] == number:
            return course
    available = ", ".join(str(item["number"]) for item in courses())
    raise ValueError(f"Семинар {number} не установлен. Доступны: {available}.")

def completed(course, root=None):
    root = STATE if root is None else root
    folder = root / f"seminar-{course['number']:02d}"
    total = len(course["ids"])
    try:
        if course["legacy"]:
            path = folder / "progress-v2"
            if path.is_file():
                step = int(path.read_text().strip())
            elif (folder / "progress").is_file():
                migration = {
                    1: 1, 2: 4, 3: 7, 4: 12, 5: 14,
                    6: 16, 7: 20, 8: 22, 9: 23, 10: 25
                }
                step = migration[int((folder / "progress").read_text().strip())]
            else:
                return 0
            return step - 1 if 1 <= step <= total + 1 else None

        path = folder / "progress-id-v1"
        if not path.is_file():
            return 0
        value = path.read_text().strip()
        value = resolve_progress(Path(course["module"]), value)
        if value == "complete":
            return total
        return course["ids"].index(value)
    except (OSError, ValueError, KeyError):
        return None

def progress_line(course):
    done = completed(course)
    total = len(course["ids"])
    if done is None:
        return "Прогресс требует проверки"
    percent = done * 100 // total
    filled = done * 16 // total
    bar = "█" * filled + "░" * (16 - filled)
    return f"{bar}  {percent}% · {done}/{total}"

def last_course():
    available = courses()
    try:
        number = int((STATE / "last-seminar").read_text().strip())
        return course_by(number)
    except (OSError, ValueError):
        return available[0]

def remember(course):
    atomic_write(
        STATE / "last-seminar",
        str(course["number"]) + "\n"
    )

def show_stats():
    catalog = courses()
    lines = []
    steps_done = 0
    steps_total = 0
    finished = 0
    damaged = 0

    for course in catalog:
        done = completed(course)
        total = len(course["ids"])
        steps_total += total
        if done is None:
            damaged += 1
        else:
            steps_done += done
            finished += int(done == total)
        lines.extend([
            f"{course['number']}. {course['title']}",
            "   " + progress_line(course),
            ""
        ])

    lines.append(f"Завершено семинаров: {finished}/{len(catalog)}")
    lines.append(f"Пройдено шагов: {steps_done}/{steps_total}")
    if damaged:
        lines.append("Некорректные записи прогресса не изменялись.")

    box("СТАТИСТИКА", "\n".join(lines), GREEN)

def show_help():
    box("КОМАНДЫ LEARN", """learn                 главное меню
learn start 2         открыть второй семинар
learn menu            вернуться в главное меню
learn stats           статистика всех семинаров
learn status          прогресс выбранного семинара
learn task 4          задание конкретного семинара
learn restart 2       архивировать попытку и начать заново

Внутри занятия:
learn task            текущее задание
learn hint            подсказка
learn check           проверка результата
learn done            отметить самостоятельный шаг
exit                  вернуться в главное меню

Обновление:
learn update --check  проверить обновления
learn update          установить обновления""")

def choose(title):
    clear()
    body = []
    for course in courses():
        body.extend([
            f"{course['number']}. {course['title']}",
            "   " + progress_line(course),
            ""
        ])
    box(title, "\n".join(body))
    while True:
        value = ask("\nНомер семинара [Enter — назад]: ")
        if value in (None, ""):
            return None
        try:
            return selected_course(value)
        except ValueError as error:
            print(error)

def parent_available():
    try:
        if os.environ.get("LEARN_FRONTEND") != "1":
            return False
        path = Path(os.environ["LEARN_REQUEST_FILE"])
        if not path.is_file() or path.is_symlink():
            return False
        os.kill(int(os.environ["LEARN_MENU_PID"]), 0)
        return True
    except (OSError, ValueError, KeyError):
        return False

def send_request(action, number=None):
    request = {"action": action}
    if number is not None:
        request["number"] = number
    atomic_write(
        Path(os.environ["LEARN_REQUEST_FILE"]),
        json.dumps(request) + "\n"
    )

def run_lesson(course):
    remember(course)

    with tempfile.TemporaryDirectory(prefix="aledu-menu-") as folder:
        request_file = Path(folder) / "request.json"
        request_file.write_text("", encoding="utf-8")
        request_file.chmod(0o600)

        env = clean_env()
        env.update({
            "LEARN_FRONTEND": "1",
            "LEARN_MENU_PID": str(os.getpid()),
            "LEARN_REQUEST_FILE": str(request_file),
        })

        child = subprocess.Popen(
            [str(ENGINE), "start", str(course["number"])],
            env=env
        )

        # Ctrl+C обрабатывает учебная оболочка; главное меню ждёт её выхода.
        previous = signal.signal(signal.SIGINT, signal.SIG_IGN)
        try:
            code = child.wait()
        finally:
            signal.signal(signal.SIGINT, previous)

        content = request_file.read_text(encoding="utf-8").strip()
        if content:
            request = json.loads(content)
            if request.get("action") in ("start", "restart"):
                course_by(request["number"])
                return request
            if request.get("action") != "menu":
                raise ValueError("Неизвестный запрос учебной оболочки.")

        if code:
            print(f"\nУчебная оболочка завершилась с кодом {code}.")
            pause()

    return None

def restart(course):
    number = course["number"]
    filename = "progress-v2" if course["legacy"] else "progress-id-v1"
    first = "1" if course["legacy"] else course["ids"][0]
    archive = archive_attempt(
        HOME / f"seminar{number}", STATE / f"seminar-{number:02d}",
        HOME / f"seminar{number}-archives", filename, first, atomic_write
    )
    clear()
    box("ПРОШЛАЯ ПОПЫТКА СОХРАНЕНА", str(archive), GREEN)
    pause()


def update(arguments):
    if not Path("/usr/lib/aledu-learn/update.py").is_file():
        print("Обработчик обновлений ещё не установлен.")
        return 1
    return subprocess.run(
        [str(ENGINE), "update", *arguments],
        env=clean_env()
    ).returncode

def update_menu():
    clear()
    box("ОБНОВЛЕНИЕ", """1. Проверить доступные обновления
2. Установить обновления
Enter — назад""")
    value = ask("\nВыбор: ")
    if value == "1":
        update(["--check"])
        pause()
    elif value == "2":
        update([])
        pause()

def menu_loop(initial=None):
    if os.geteuid() == 0:
        print("Открывай Learn обычным пользователем, без sudo.")
        return 1
    if not sys.stdin.isatty():
        print("Открой Learn в окне терминала.")
        return 1

    pending = initial

    while True:
        try:
            if pending:
                action = pending
                pending = None
                course = course_by(action["number"])
                if action["action"] == "restart":
                    restart(course)
                pending = run_lesson(course)
                continue

            course = last_course()
            count = completed(course)
            if count == len(course["ids"]):
                resume_label = "1. Посмотреть итоги завершённого семинара"
            elif count is None:
                resume_label = "1. Открыть семинар — прогресс требует проверки"
            else:
                resume_label = f"1. Продолжить с шага {count + 1}"
            clear()
            box("ALEDU LEARN",
                f"Семинар {course['number']} · {course['title']}\n"
                + progress_line(course),
                PURPLE)
            print()
            box("ГЛАВНОЕ МЕНЮ", f"""{resume_label}
2. Выбрать семинар
3. Статистика
4. Начать семинар заново — с сохранением архива
5. Команды и справка
6. Обновление Learn

0. Выйти из приложения""")

            value = ask("\nВыбор [Enter — продолжить]: ")

            if value in (None, "0"):
                return 0
            if value in ("", "1"):
                pending = {"action": "start", "number": course["number"]}
            elif value in ("2", "4"):
                selected = choose(
                    "ВЫБОР СЕМИНАРА" if value == "2"
                    else "ПОВТОРНОЕ ПРОХОЖДЕНИЕ"
                )
                if selected:
                    pending = {
                        "action": "start" if value == "2" else "restart",
                        "number": selected["number"]
                    }
            elif value == "3":
                clear()
                show_stats()
                pause()
            elif value == "5":
                clear()
                show_help()
                pause()
            elif value == "6":
                update_menu()
            else:
                print("Выбери пункт меню.")
                pause()

        except KeyboardInterrupt:
            print()
            pending = None
        except (OSError, ValueError, KeyError) as error:
            box("НЕ УДАЛОСЬ ВЫПОЛНИТЬ ДЕЙСТВИЕ", str(error), YELLOW)
            pause()

def selected_course(raw):
    if not str(raw).isascii() or not str(raw).isdigit():
        raise ValueError("Укажи номер семинара числом, например: learn start 4.")
    return course_by(int(raw))


def main():
    arguments = sys.argv[1:]
    command = arguments[0] if arguments else "menu"
    active = (
        os.environ.get("LEARN_ACTIVE") == "1"
        and parent_available()
    )

    if command in ("start", "restart"):
        if len(arguments) > 2:
            raise ValueError("Пример: learn start 2")
        raw = arguments[1] if len(arguments) == 2 else (
            os.environ.get("LEARN_SEMINAR", "1") if active
            else str(last_course()["number"])
        )
        course = selected_course(raw)

        if parent_available():
            if active and str(os.getppid()) != os.environ.get("LEARN_SESSION_PID"):
                print("Переключай семинар из основной учебной оболочки.")
                print("Сначала выйди из вложенного Bash или отсоединись от tmux.")
                return 1
            send_request(command, course["number"])
            return 42 if active else 0

        return menu_loop({
            "action": command,
            "number": course["number"]
        })

    if command == "menu":
        if len(arguments) > 1:
            raise ValueError("Главное меню: learn")
        if active:
            if str(os.getppid()) != os.environ.get("LEARN_SESSION_PID"):
                print("Вернись в основную учебную оболочку и введи learn menu.")
                return 1
            send_request("menu")
            return 42
        return menu_loop()

    if command == "stats":
        show_stats()
        return 0

    if command in ("help", "--help", "-h"):
        show_help()
        return 0

    if command == "update":
        if active:
            print("Сначала вернись в главное меню: learn menu")
            return 1
        return update(arguments[1:])

    lesson_commands = ("task", "hint", "status", "results", "check", "done")
    if command in lesson_commands:
        if len(arguments) > 2:
            raise ValueError(f"Используй learn {command} или learn {command} НОМЕР.")
        course = selected_course(arguments[1]) if len(arguments) == 2 else (
            course_by(int(os.environ["LEARN_SEMINAR"])) if active else last_course()
        )
        if command in ("check", "done") and not active:
            print(f"Сначала открой учебную оболочку: learn start {course['number']}")
            return 1
        if active and str(course["number"]) != os.environ.get("LEARN_SEMINAR"):
            if command in ("check", "done"):
                print(f"Сначала переключи семинар: learn start {course['number']}")
                return 1
        env = os.environ.copy() if active else clean_env()
        if active and str(course["number"]) != os.environ.get("LEARN_SEMINAR"):
            env = clean_env()
        os.execve(str(ENGINE), [str(ENGINE), command, str(course["number"])], env)

    env = os.environ.copy() if active else clean_env()
    os.execve(str(ENGINE), [str(ENGINE), *arguments], env)

if __name__ == "__main__":
    try:
        sys.exit(main())
    except (OSError, ValueError, KeyError) as error:
        print(f"Learn: {error}", file=sys.stderr)
        sys.exit(1)
