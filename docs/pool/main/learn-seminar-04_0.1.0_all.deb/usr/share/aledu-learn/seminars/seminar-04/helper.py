#!/usr/bin/env python3
"""Prepare fresh local fixtures; check objects and indexes without running learner code."""
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import stat
import subprocess
import sys
import tempfile

MODULE = Path(__file__).resolve().parent
GIT = '/usr/bin/git' if os.name!='nt' else (shutil.which('git') or 'git')
HELLO = 'Привет, Git!\nЭто файл для первого коммита.\n'.encode()
NOTES = '# Заметки\n\n- выучить git status\n- выучить git add\n- выучить git commit\n'.encode()
NOTES2 = NOTES+'- изучить git diff\n'.encode()
FEATURE = 'Функция из dev\n'.encode()
UPDATE = 'Обновление с сервера\n'.encode()
PATCHLINE = '\nИзменение через patch\n'.encode()
WIP = '\nНезавершённая работа\n'.encode()
HOTFIX = 'Срочное исправление\n'.encode()
RESOLVED = 'Строка 1\nСтрока 2: итог\nСтрока 3\n'.encode()


class Incomplete(Exception):
    pass


def need(value,message):
    if not value:
        raise Incomplete(message)


def path(lab,relative):
    rel = Path(relative)
    if rel.is_absolute() or '..' in rel.parts:
        raise ValueError('Неверный внутренний путь.')
    current = lab
    for i,part in enumerate(rel.parts):
        current = current/part
        need(not current.is_symlink(),f'{relative}: путь не должен быть символической ссылкой.')
        if i<len(rel.parts)-1:
            need(not current.exists() or current.is_dir(),f'{relative}: один из каталогов заменён файлом.')
    return current


def read(lab,relative):
    p = path(lab,relative)
    try:
        mode = p.lstat().st_mode
    except FileNotFoundError:
        raise Incomplete(f'Не найден файл: {relative}') from None
    need(stat.S_ISREG(mode) and p.stat().st_size<2_000_000,f'{relative}: нужен обычный учебный файл.')
    return p.read_bytes()


def environment():
    env = {k:v for k,v in os.environ.items() if not k.startswith('GIT_')}
    env.update(GIT_CONFIG_NOSYSTEM='1',GIT_CONFIG_GLOBAL=os.devnull,
               GIT_OPTIONAL_LOCKS='0',GIT_NO_REPLACE_OBJECTS='1',
               GIT_NO_LAZY_FETCH='1',GIT_ATTR_NOSYSTEM='1',
               GIT_TERMINAL_PROMPT='0',LC_ALL='C')
    return env


def command(repo,*args,bare=False,input=None,allow_fail=False,seed_env=None):
    """No shell, network operations, worktree filters, user pagers or hooks in checks."""
    gitdir = repo if bare else repo/'.git'
    options = [GIT,'--no-pager',f'--git-dir={gitdir}']
    if not bare:
        options += [f'--work-tree={repo}']
    options += ['-c',f'core.hooksPath={os.devnull}','-c','core.fsmonitor=false',
                '-c','gc.auto=0','-c','maintenance.auto=false',
                '-c','commit.gpgSign=false','-c','log.showSignature=false']
    env = environment()
    if seed_env:
        env.update(seed_env)
    result = subprocess.run(options+list(args),input=input,env=env,
                            capture_output=True,timeout=20)
    if result.returncode and not allow_fail:
        raise Incomplete(f'{repo.name}: Git не смог прочитать нужный объект или состояние репозитория.')
    if len(result.stdout)>2_000_000:
        raise Incomplete(f'{repo.name}: слишком большой вывод Git для учебной проверки.')
    return result


def repository(lab,name,bare=False):
    p = path(lab,name)
    need(p.is_dir(),f'Не найден каталог {name}.')
    if not bare:
        need(path(lab,name+'/.git').is_dir(),f'{name}: сначала создай обычный Git-репозиторий.')
    # Reject redirected metadata before asking Git to read it.
    for rel in ('config','HEAD','index','objects','refs','commondir'):
        item = (p if bare else p/'.git')/rel
        need(not item.is_symlink(),f'{name}: служебный путь {rel} не должен быть ссылкой.')
    need(not ((p if bare else p/'.git')/'commondir').exists(),f'{name}: нужен самостоятельный учебный репозиторий.')
    return p


def g(repo,*args,bare=False):
    return command(repo,*args,bare=bare).stdout


def ref(repo,name='HEAD',bare=False,optional=False):
    result = command(repo,'rev-parse','--verify',name,bare=bare,allow_fail=True)
    if result.returncode:
        if optional:
            return None
        raise Incomplete(f'{repo.name}: не найдена версия {name}.')
    value = result.stdout.decode().strip()
    need(bool(re.fullmatch('[0-9a-f]{40}',value)),f'{repo.name}: ожидается учебный репозиторий SHA-1.')
    return value


def branch(repo):
    result = command(repo,'symbolic-ref','--quiet','--short','HEAD',allow_fail=True)
    return result.stdout.decode().strip() if not result.returncode else None


def tree(repo,revision='HEAD'):
    entries = {}
    for record in g(repo,'ls-tree','-r','-z',revision).split(b'\0'):
        if not record:
            continue
        metadata,name = record.split(b'\t',1)
        mode,kind,oid = metadata.decode().split()
        need(kind=='blob' and mode in ('100644','100755'),f'{repo.name}: в задании нужны обычные файлы.')
        entries[name.decode()] = oid
    return entries


def index(repo):
    entries = {}
    for record in g(repo,'ls-files','--stage','-z').split(b'\0'):
        if record:
            metadata,name = record.split(b'\t',1)
            mode,oid,stage = metadata.decode().split()
            entries[(name.decode(),int(stage))] = oid
    return entries


def blob(repo,filename,revision='HEAD'):
    entries = tree(repo,revision)
    need(filename in entries,f'{repo.name}: в {revision} нет файла {filename}.')
    return g(repo,'cat-file','blob',entries[filename])


def parents(repo,revision='HEAD'):
    return g(repo,'rev-list','--parents','-n','1',revision).decode().split()[1:]


def ancestor(repo,older,newer):
    result = command(repo,'merge-base','--is-ancestor',older,newer,allow_fail=True)
    need(result.returncode in (0,1),f'{repo.name}: не удалось сравнить историю.')
    return result.returncode==0


def clean(lab,repo):
    entries = tree(repo)
    need(index(repo)=={(name,0):oid for name,oid in entries.items()},f'{repo.name}: индекс отличается от HEAD или есть неразрешённый конфликт.')
    for name,oid in entries.items():
        raw = read(lab,repo.name+'/'+name)
        expected = hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
        need(expected==oid,f'{repo.name}/{name}: есть незакоммиченные изменения.')


def local_remote(lab,repo):
    raw = command(repo,'config','--local','--get','remote.origin.url',allow_fail=True).stdout.decode().strip()
    need(bool(raw),f'{repo.name}: добавь origin, указывающий на учебный remote.git.')
    need('://' not in raw and not raw.startswith(('-','ext::')) and '\n' not in raw,
         f'{repo.name}: origin должен указывать на локальный ../remote.git.')
    candidate = Path(raw)
    if not candidate.is_absolute():
        candidate = repo/candidate
    need(candidate.resolve()==(lab/'remote.git').resolve(),f'{repo.name}: origin указывает не на учебный remote.git.')


def worktrees(repo):
    result = []
    for block in g(repo,'worktree','list','--porcelain','-z').split(b'\0\0'):
        item = {}
        for line in block.split(b'\0'):
            if b' ' in line:
                key,value = line.decode().split(' ',1)
                item[key] = value
        if item:
            result.append(item)
    return result


def check(lab,task):
    n = int(task[-3:])
    seed = json.loads((MODULE/'assets/seed-hashes.json').read_text())
    if n==1:
        need(read(lab,'01-basics/hello.txt')==HELLO,'В 01-basics не найден исходный hello.txt.')
        read(lab,'01-basics/notes.md')
        for name in ('02-branching','03-history','04-rebase','05-recovery'):
            repository(lab,name)
        repository(lab,'remote.git',True)
    elif n in (2,3,4,5,7,8,9,10,11,12,16,18,29,31,32,33,34):
        repo = repository(lab,'01-basics')
        if n==2:
            need(branch(repo)=='main','Инициализируй 01-basics с веткой main.')
            name = command(repo,'config','--local','--get','user.name',allow_fail=True).stdout.decode().strip()
            email = command(repo,'config','--local','--get','user.email',allow_fail=True).stdout.decode().strip()
            need(name and '@' in email,'Задай локальные user.name и user.email в 01-basics.')
        elif n==3:
            expected = hashlib.sha1(b'blob '+str(len(HELLO)).encode()+b'\0'+HELLO).hexdigest()
            need(ref(repo,optional=True) is None,'Этот шаг выполняется до первого коммита.')
            need(index(repo)=={('hello.txt',0):expected},'Добавь в индекс только hello.txt; notes.md пока не добавляй.')
        elif n==4:
            need(g(repo,'rev-list','--count','HEAD').strip()==b'1','Нужен один первый коммит.')
            need(set(tree(repo))=={'hello.txt'} and blob(repo,'hello.txt')==HELLO,
                 'Первый коммит должен содержать только исходный hello.txt.')
            clean(lab,repo)
        elif n==5:
            need(g(repo,'rev-list','--count','HEAD').strip()==b'2','Добавь notes.md отдельным вторым коммитом.')
            need(blob(repo,'notes.md')==NOTES2,'Добавь в notes.md строку «- изучить git diff» и закоммить файл.')
            clean(lab,repo)
        elif n==7:
            clean(lab,repo)
            need(blob(repo,'hello.txt')==HELLO,'Отмени учебное изменение hello.txt, сохранив исходный текст.')
        elif n==8:
            need(g(repo,'rev-list','--count','HEAD').strip()==b'2','Исправь второй коммит через --amend, не создавая третий.')
            raw = g(repo,'cat-file','commit',ref(repo))
            need(raw.split(b'\n\n',1)[1].strip()=='Уточнить заметки'.encode(),'Сообщение последнего коммита: Уточнить заметки.')
            need(blob(repo,'notes.md')==NOTES2,'Содержимое заметок менять не нужно.')
            clean(lab,repo)
        elif n==9:
            main = ref(repo,'refs/heads/main')
            need(branch(repo)=='dev' and ref(repo,'refs/heads/dev')==ref(repo),'Перейди в dev и создай коммит этой ветки.')
            need(blob(repo,'feature.txt')==FEATURE,'В коммите dev нужен feature.txt со строкой «Функция из dev».')
            need(parents(repo)==[main],'В dev нужен один новый коммит поверх main.')
            clean(lab,repo)
        elif n==10:
            need(branch(repo)=='main','Вернись в ветку main.')
            need(ancestor(repo,ref(repo,'refs/heads/dev'),ref(repo)),'Слей dev в main.')
            need(blob(repo,'feature.txt')==FEATURE,'После слияния main должен содержать feature.txt.')
            clean(lab,repo)
        elif n==11:
            need('build.tmp' not in tree(repo) and not any(name=='build.tmp' for name,stage in index(repo)),
                 'build.tmp не должен попадать в историю или индекс.')
            read(lab,'01-basics/build.tmp')
            need('.gitignore' in tree(repo),'Закоммить файл .gitignore.')
            ignored = command(repo,'check-ignore','--no-index','build.tmp',allow_fail=True)
            need(ignored.returncode==0,'Правило .gitignore не исключает build.tmp.')
            clean(lab,repo)
        elif n==12:
            first = parents(repo)
            need(len(first)==1,'Ожидается обычный коммит отмены.')
            previous = first[0]
            older = parents(repo,previous)
            need(len(older)==1 and 'mistake.txt' in tree(repo,previous),
                 'Сначала создай отдельный коммит с mistake.txt, затем отмени его через revert.')
            need(tree(repo)==tree(repo,older[0]) and 'mistake.txt' not in tree(repo),
                 'Отмена должна вернуть прежнее дерево, сохранив ошибочный коммит в истории.')
            clean(lab,repo)
        elif n in (16,18):
            local_remote(lab,repo)
            remote = repository(lab,'remote.git',True)
            need(branch(repo)=='main' and ref(remote,'refs/heads/main',True)==ref(repo),
                 'Отправь текущую main в учебный remote.git.')
            if n==18:
                need(blob(repo,'update.txt')==UPDATE,'Закоммить update.txt со строкой «Обновление с сервера», затем push.')
            clean(lab,repo)
        elif n==29:
            need(ref(repo,'refs/tags/v1.0^{}')==ref(repo,'refs/heads/main'),'Создай тег v1.0 на текущей main.')
        elif n==31:
            need(blob(repo,'hello.txt')==HELLO+PATCHLINE,'В последнем коммите hello.txt должен содержать строку «Изменение через patch».')
            need(blob(repo,'hello.txt','HEAD^')==HELLO,'Сохрани изменение из patch отдельным коммитом.')
            patch = read(lab,'hello.patch')
            need(b'--- a/hello.txt' in patch and b'+++ b/hello.txt' in patch and
                 '+Изменение через patch'.encode() in patch,'Сохрани обычный hello.patch через git diff.')
            clean(lab,repo)
        elif n==32:
            need(branch(repo)=='main','Основное рабочее дерево должно оставаться на main.')
            need(read(lab,'01-basics/hello.txt')==blob(repo,'hello.txt')+WIP,
                 'В основном hello.txt оставь незакоммиченную строку «Незавершённая работа».')
            entries = worktrees(repo)
            extra = [item for item in entries if item.get('branch')=='refs/heads/worktree-hotfix']
            need(len(entries)==2 and len(extra)==1 and Path(extra[0]['worktree']).resolve()==(lab/'01-hotfix').resolve(),
                 'Создай ../01-hotfix как worktree новой ветки worktree-hotfix.')
            need(read(lab,'01-hotfix/hello.txt')==blob(repo,'hello.txt'),'Незакоммиченная строка не должна появиться в дополнительном дереве.')
        elif n==33:
            need(branch(repo)=='main' and len(parents(repo))==2,'Сохрани свою работу и слей worktree-hotfix в main.')
            need(ancestor(repo,ref(repo,'refs/heads/worktree-hotfix'),ref(repo)), 'Исправление ещё не слито в main.')
            need(blob(repo,'hotfix.txt')==HOTFIX and blob(repo,'hello.txt')==HELLO+PATCHLINE+WIP,
                 'В main должны сохраниться hotfix.txt и строка незавершённой работы.')
            clean(lab,repo)
        elif n==34:
            need(len(worktrees(repo))==1 and not path(lab,'01-hotfix').exists(),'Удали дополнительное дерево через git worktree remove.')
            need(ref(repo,'refs/heads/worktree-hotfix',optional=True) is None,'Удали уже слитую ветку worktree-hotfix.')
    elif n in (14,15):
        repo = repository(lab,'02-branching')
        if n==14:
            merge = read(lab,'02-branching/.git/MERGE_HEAD').decode().strip()
            need(merge==seed['02-branching']['feature'],'Начни merge feature из main.')
            entries = index(repo)
            need({stage for (name,stage) in entries if name=='message.txt'}=={1,2,3},'Нужен незавершённый конфликт message.txt.')
        else:
            need(branch(repo)=='main' and set(parents(repo))==set(seed['02-branching'].values()),
                 'Заверши слияние двух исходных веток merge-коммитом.')
            need(not path(lab,'02-branching/.git/MERGE_HEAD').exists(),'Слияние ещё не завершено.')
            need(blob(repo,'message.txt')==RESOLVED,'Вторая строка результата: «Строка 2: итог»; первую и третью сохрани.')
            clean(lab,repo)
    elif n in (17,20):
        repo = repository(lab,'myclone')
        remote = repository(lab,'remote.git',True)
        local_remote(lab,repo)
        need(branch(repo)=='main' and ref(repo)==ref(remote,'refs/heads/main',True),'Обнови main клона до версии учебного сервера.')
        if n==20:
            need(blob(repo,'update.txt')==UPDATE,'После pull в клоне должен появиться update.txt.')
        clean(lab,repo)
    elif n==22:
        repo = repository(lab,'03-history')
        need(ref(repo,'refs/tags/first-bad^{}')==seed['03-history']['bad'],'Тег first-bad должен указывать на найденный первый плохой коммит.')
        need(branch(repo)=='main' and ref(repo)==seed['03-history']['main'],'После поиска выполни git bisect reset.')
        need(not path(lab,'03-history/.git/BISECT_START').exists(),'Поиск bisect ещё не завершён.')
        clean(lab,repo)
    elif n in (23,24,25,26,27):
        repo = repository(lab,'04-rebase')
        baseline = seed['04-rebase']
        need(ref(repo,'refs/heads/feature-before-rebase')==baseline['feature'],'Сначала сохрани исходную feature веткой feature-before-rebase.')
        if n==23:
            need(branch(repo)=='feature' and ref(repo)==baseline['feature'],'Перейди в исходную ветку feature.')
        elif n in (24,25,26):
            step = n-24
            need(ref(repo,'REBASE_HEAD')==baseline['commits'][step],'Ожидалась остановка rebase на коммите версии '+str(step+1)+'.')
            need(any(stage>0 for name,stage in index(repo)),'На этом шаге должен оставаться конфликт следующего коммита.')
            if step:
                expected = f'Текст main\nТекст feature: версия {step}\n'.encode()
                need(blob(repo,'message.txt')==expected,'В перенесённом коммите должны сохраниться main и предыдущая версия feature.')
        else:
            active = any(path(lab,'04-rebase/.git/'+name).exists() for name in ('rebase-merge','rebase-apply'))
            need(branch(repo)=='feature' and not active,'Заверши все остановки rebase.')
            main = ref(repo,'refs/heads/main')
            need(main==baseline['main'] and ancestor(repo,main,ref(repo)), 'Новая feature должна продолжать main.')
            commits = g(repo,'rev-list',main+'..HEAD').decode().split()
            need(len(commits)==3 and all(len(parents(repo,c))==1 for c in commits),'Сохрани все три коммита без merge-коммита.')
            need(blob(repo,'message.txt')=='Текст main\nТекст feature: версия 3\n'.encode(),'Итог: две строки — main и версия 3 feature.')
            clean(lab,repo)
    else:
        raise ValueError('Для этого задания нет автоматической проверки.')
    print('Состояние файлов и Git-истории соответствует заданию.')


def seed_commit(repo,name,email,date,message):
    command(repo,'add','-A')
    command(repo,'commit','-q','-m',message,seed_env={
        'GIT_AUTHOR_NAME':name,'GIT_AUTHOR_EMAIL':email,
        'GIT_COMMITTER_NAME':name,'GIT_COMMITTER_EMAIL':email,
        'GIT_AUTHOR_DATE':date,'GIT_COMMITTER_DATE':date})


def create_fixture(root):
    """Only called in a brand-new private staging directory, never on student repos."""
    template = root/'.empty-template'
    template.mkdir()
    def init(name,bare=False):
        p = root/name
        args = [GIT,'-c','init.defaultBranch=main','init','-q','-b','main',
                '--object-format=sha1','--template='+str(template)]
        if bare:
            args.append('--bare')
        subprocess.run(args+[str(p)],env=environment(),check=True,capture_output=True)
        if not bare:
            for key,value in [('core.autocrlf','false'),('core.filemode','false'),
                              ('user.name','Student'),('user.email','student@aledu.invalid'),
                              ('commit.gpgSign','false'),('rerere.enabled','false')]:
                command(p,'config','--local',key,value)
        return p
    def put(repo,name,text):
        (repo/name).write_bytes(text.encode() if isinstance(text,str) else text)
    def commit(repo,day,message,author='Студент',email='student@aledu.invalid'):
        seed_commit(repo,author,email,f'2025-01-{day:02}T10:00:00+00:00',message)
    basics = root/'01-basics'
    basics.mkdir()
    put(basics,'hello.txt',HELLO)
    put(basics,'notes.md',NOTES)
    branch_repo = init('02-branching')
    put(branch_repo,'message.txt','Строка 1\nСтрока 2: общее\nСтрока 3\n')
    commit(branch_repo,6,'добавить message.txt')
    command(branch_repo,'switch','-q','-c','feature')
    put(branch_repo,'message.txt','Строка 1\nСтрока 2: изменение в feature\nСтрока 3\n')
    commit(branch_repo,8,'feature: изменить вторую строку')
    feature = ref(branch_repo)
    command(branch_repo,'switch','-q','main')
    put(branch_repo,'message.txt','Строка 1\nСтрока 2: изменение в main\nСтрока 3\n')
    commit(branch_repo,9,'main: изменить вторую строку')
    seeds = {'02-branching':{'main':ref(branch_repo),'feature':feature}}
    history = init('03-history')
    put(history,'compute.sh','#!/bin/bash\necho $((6 * 7))\n')
    put(history,'test.sh','#!/bin/bash\nif [ "$(bash compute.sh)" = "42" ]; then\n    echo OK\n    exit 0\nfi\necho FAIL\nexit 1\n')
    commit(history,6,'инициализация: compute.sh и test.sh','Алиса','alice@aledu.invalid')
    good = ref(history)
    text = ''
    for day,author,email,line in [(7,'Алиса','alice@aledu.invalid','строка от Алисы'),
                                  (8,'Боб','bob@aledu.invalid','строка от Боба'),
                                  (9,'Каролина','carol@aledu.invalid','строка от Каролины')]:
        text += line+'\n'
        put(history,'notes.txt',text)
        commit(history,day,'notes: '+line,author,email)
    put(history,'compute.sh','#!/bin/bash\n# Ключевой результат\necho $((6 * 7))\n')
    commit(history,10,'compute: уточнить формулу','Алиса','alice@aledu.invalid')
    put(history,'compute.sh','#!/bin/bash\n# Ключевой результат\necho $((6 + 7))\n')
    commit(history,11,'compute: упростить выражение','Боб','bob@aledu.invalid')
    bad = ref(history)
    put(history,'notes.txt',text+'строка после бага\n')
    commit(history,12,'notes: последняя строка','Каролина','carol@aledu.invalid')
    seeds['03-history'] = {'good':good,'bad':bad,'main':ref(history)}
    rebase = init('04-rebase')
    put(rebase,'message.txt','Общий текст\n')
    commit(rebase,6,'добавить message.txt')
    command(rebase,'switch','-q','-c','feature')
    commits = []
    for version in range(1,4):
        put(rebase,'message.txt',f'Текст feature: версия {version}\n')
        commit(rebase,8,f'feature: версия {version} в message.txt')
        commits.append(ref(rebase))
    command(rebase,'switch','-q','main')
    put(rebase,'message.txt','Текст main\n')
    commit(rebase,9,'main: изменить message.txt')
    seeds['04-rebase'] = {'main':ref(rebase),'feature':commits[-1],'commits':commits}
    recovery = init('05-recovery')
    put(recovery,'state.txt','Исходное состояние\n')
    commit(recovery,6,'сохранить исходное состояние')
    init('remote.git',True)
    return seeds


def setup(lab):
    if hasattr(os,'geteuid') and os.geteuid()==0:
        raise ValueError('Открывай Learn обычным пользователем, без sudo.')
    lab.mkdir(parents=True,exist_ok=True)
    names = ('01-basics','02-branching','03-history','04-rebase','05-recovery','remote.git')
    for name in names:
        target = path(lab,name)
        need(not target.exists() or target.is_dir(),f'{name}: ожидался каталог.')
    missing = [name for name in names if not (lab/name).exists()]
    if not missing:
        print('Учебные репозитории уже готовы; твоя работа сохранена.')
        return
    if not shutil.which('git'):
        raise ValueError('Не найден Git. Переустанови пакет семинара с зависимостями.')
    with tempfile.TemporaryDirectory(prefix='.aledu-setup-',dir=lab) as temp:
        staging = Path(temp)
        seeds = create_fixture(staging)
        reference = MODULE/'assets/seed-hashes.json'
        if reference.exists() and seeds!=json.loads(reference.read_text()):
            raise ValueError('История стенда отличается от эталонной. Работа пользователя не изменялась.')
        for name in missing:
            need(not (lab/name).exists() and not (lab/name).is_symlink(),f'{name}: каталог изменился во время подготовки.')
            (staging/name).rename(lab/name)
    print('Учебные репозитории готовы. Уже существующие каталоги сохранены.')


def main():
    if len(sys.argv)<3 or sys.argv[1] not in ('setup','check'):
        raise ValueError('Ожидалось setup КАТАЛОГ или check КАТАЛОГ ID.')
    action = sys.argv[1]
    if len(sys.argv)!=(3 if action=='setup' else 4):
        raise ValueError('Неверное число аргументов.')
    lab = Path(sys.argv[2])
    if not lab.is_absolute() or lab!=Path(os.environ['HOME'])/'seminar4' or lab.is_symlink():
        raise ValueError('Ожидался обычный каталог $HOME/seminar4.')
    if action=='setup':
        setup(lab)
    else:
        lesson = json.loads((MODULE/'lesson.json').read_text())
        modes = {t['id']:t['mode'] for t in lesson['tasks']}
        if modes.get(sys.argv[3])!='auto':
            raise ValueError('Неизвестный ID или шаг с самостоятельной проверкой.')
        check(lab,sys.argv[3])


if __name__=='__main__':
    try:
        main()
    except Incomplete as error:
        print(error)
        sys.exit(1)
    except (OSError,ValueError,KeyError,subprocess.SubprocessError) as error:
        print(f'Ошибка подготовки/проверки: {error}',file=sys.stderr)
        sys.exit(2)
