#!/usr/bin/env python3
"""Seminar 3: preserve student work; inspect artifacts without executing them."""
import json
import os
from pathlib import Path
import re
import stat
import struct
import sys

MODULE = Path(__file__).resolve().parent
SYMBOLS = dict(main='main', tokenizer='tokenizer_collect', stats='stats_from_file',
               formatter='formatter_print', policy='policy_score')
LIB_SYMBOLS = {'tokenizer_collect', 'stats_from_file', 'formatter_print',
               'policy_name', 'policy_score'}


class Incomplete(Exception):
    pass


def need(ok, message):
    if not ok:
        raise Incomplete(message)


def local(lab, relative):
    rel = Path(relative)
    if rel.is_absolute() or '..' in rel.parts:
        raise ValueError('Недопустимый внутренний путь проверки.')
    current = lab
    for index,part in enumerate(rel.parts):
        current = current / part
        need(not current.is_symlink(), f'{relative}: нужна работа внутри семинара, без символических ссылок.')
        if index<len(rel.parts)-1:
            need(not current.exists() or current.is_dir(), f'{current.relative_to(lab)}: ожидался каталог.')
    return current


def read(lab, relative, limit=32*1024*1024):
    path = local(lab, relative)
    try:
        mode = path.lstat().st_mode
    except FileNotFoundError:
        raise Incomplete(f'Не найден файл: {relative}') from None
    need(stat.S_ISREG(mode), f'{relative}: нужен обычный файл.')
    need(path.stat().st_size <= limit, f'{relative}: файл слишком велик для учебной проверки.')
    return path.read_bytes()


def text(lab, relative):
    return read(lab, relative, 4*1024*1024).decode('utf-8', errors='replace')


def directory(lab, relative):
    need(local(lab, relative).is_dir(), f'Создай каталог: {relative}')


def same(lab, relative):
    expected = (MODULE / 'assets/code' / relative).read_bytes()
    need(read(lab, relative)==expected, f'{relative}: восстанови исходный файл; алгоритмы и данные менять не нужно.')


def sources(lab, include_data=False):
    for path in sorted((MODULE / 'assets/code').rglob('*')):
        if path.is_file() and (path.suffix in ('.c','.h') or
                              (include_data and path.parent.name=='data')):
            same(lab, path.relative_to(MODULE / 'assets/code').as_posix())


class Elf:
    """Small bounds-checked ELF reader; never loads or runs code."""
    def __init__(self, raw):
        self.raw = raw
        if len(raw)<64 or raw[:4]!=b'\x7fELF' or raw[4] not in (1,2) or raw[5] not in (1,2):
            raise ValueError('ожидался ELF-файл')
        self.bits = raw[4]
        self.endian = '<' if raw[5]==1 else '>'
        fmt = 'HHIIIIIHHHHHH' if self.bits==1 else 'HHIQQQIHHHHHH'
        header = self.unpack(fmt,16)
        self.type, self.machine, version, entry, phoff, shoff, flags, ehsize, phentsize, phnum, shentsize, shnum, shstr = header
        if version!=1 or not shnum or shnum>8192 or shstr>=shnum:
            raise ValueError('повреждённая таблица секций ELF')
        sfmt = 'IIIIIIIIII' if self.bits==1 else 'IIQQQQIIQQ'
        slen = struct.calcsize(self.endian+sfmt)
        if shentsize<slen:
            raise ValueError('неверный размер секции ELF')
        self.sections = [self.unpack(sfmt,shoff+i*shentsize) for i in range(shnum)]
        for sec in self.sections:
            if sec[1]!=8:  # SHT_NOBITS has no file bytes.
                self.slice(sec[4],sec[5])
        self.names = self.section_data(shstr)

    def slice(self, offset, size):
        if offset<0 or size<0 or offset+size>len(self.raw):
            raise ValueError('ELF содержит выход за границы файла')
        return self.raw[offset:offset+size]

    def unpack(self, fmt, offset):
        size = struct.calcsize(self.endian+fmt)
        return struct.unpack(self.endian+fmt,self.slice(offset,size))

    def section_data(self, index):
        if not 0<=index<len(self.sections):
            raise ValueError('неверная ссылка на секцию ELF')
        sec = self.sections[index]
        return self.slice(sec[4],sec[5])

    @staticmethod
    def string(raw, index):
        if not 0<=index<len(raw):
            raise ValueError('неверная ссылка на строку ELF')
        end = raw.find(b'\0', index)
        if end<0:
            raise ValueError('незавершённая строка ELF')
        return raw[index:end].decode('utf-8', errors='replace')

    def symbols(self, dynamic=False):
        result = set()
        for sec in self.sections:
            if sec[1] not in ((11,) if dynamic else (2,11)):
                continue
            strings = self.section_data(sec[6])
            fmt = 'IIIBBH' if self.bits==1 else 'IBBHQQ'
            size = struct.calcsize(self.endian+fmt)
            if sec[9]<size or sec[5]%sec[9]:
                raise ValueError('неверная таблица символов ELF')
            for offset in range(sec[4],sec[4]+sec[5],sec[9]):
                values = self.unpack(fmt,offset)
                name, info, other, shndx = ((values[0],values[3],values[4],values[5])
                                            if self.bits==1 else values[:4])
                # Only externally visible defined functions, not undefined references.
                if shndx and info&15==2 and info>>4 in (1,2) and other&3 in (0,3):
                    result.add(self.string(strings,name))
        return result

    def needed(self):
        result = set()
        for sec in self.sections:
            if sec[1]!=6:
                continue
            strings = self.section_data(sec[6])
            fmt = 'iI' if self.bits==1 else 'qQ'
            size = struct.calcsize(self.endian+fmt)
            if sec[9]<size or sec[5]%sec[9]:
                raise ValueError('неверная dynamic-секция ELF')
            for offset in range(sec[4],sec[4]+sec[5],sec[9]):
                tag,value = self.unpack(fmt,offset)
                if tag==0:
                    break
                if tag==1:
                    result.add(self.string(strings,value))
        return result


def elf(lab, relative, types, symbols=(), dynamic=False):
    try:
        result = Elf(read(lab,relative))
        need(result.type in types, f'{relative}: неверный тип ELF для этого этапа.')
        missing = set(symbols)-result.symbols(dynamic)
        need(not missing, f'{relative}: не найдены определения {", ".join(sorted(missing))}; не используй strip.')
        return result
    except (ValueError,struct.error,IndexError) as error:
        raise Incomplete(f'{relative}: {error}. Пересобери файл из нужного исходника.') from None


def asm(lab, relative, function):
    content = text(lab,relative)
    need(len(content)>80 and re.search(r'(?m)^'+re.escape(function)+r':',content),
         f'{relative}: не найден ассемблер с меткой {function}.')


def preprocessing(lab, relative, scale):
    content = text(lab,relative)
    need('int calculate' in content and 'scaled_value' in content and '"seminar3"' in content,
         f'{relative}: не найден препроцессированный stages.c.')
    need(not re.search(r'^\s*#\s*(include|define)\b',content,re.M),
         f'{relative}: заголовки и макросы должны быть обработаны препроцессором.')
    need(re.search(r'return\s+x\s*\*\s*'+str(scale)+r'\s*;',content),
         f'{relative}: в scaled_value ожидался раскрытый множитель {scale}.')
    need('SQUARE(' not in content, f'{relative}: SQUARE ещё не раскрыт.')


def archive(lab):
    relative = 'lib/libtextstat.a'
    raw = read(lab,relative)
    need(raw.startswith(b'!<arch>\n'), f'{relative}: нужен обычный архив ar, не thin archive.')
    offset, members = 8, {}
    try:
        while offset<len(raw):
            header = raw[offset:offset+60]
            if len(header)!=60 or header[58:60]!=b'`\n':
                raise ValueError('повреждён заголовок ar')
            size = int(header[48:58])
            start = offset+60
            if size<0 or start+size>len(raw):
                raise ValueError('повреждён размер ar')
            name = header[:16].decode('ascii').strip()
            content = raw[start:start+size]
            offset = start+size+(size%2)
            if name in ('/','//','/SYM64/'):
                continue
            name = name.removesuffix('/')
            if name in members:
                raise ValueError('повторяющиеся члены архива')
            members[name] = content
        need(set(members)=={n+'.o' for n in SYMBOLS if n!='main'},
             'libtextstat.a должен содержать только tokenizer.o, stats.o, formatter.o и policy.o.')
        for name, content in members.items():
            obj = Elf(content)
            need(obj.type==1 and SYMBOLS[name[:-2]] in obj.symbols(),
                 f'В {name} архива нет нужного ELF-объекта.')
    except (ValueError,UnicodeError,struct.error,IndexError) as error:
        raise Incomplete(f'{relative}: {error}.') from None


def makefile(lab):
    need(bool(text(lab,'Makefile').strip()), 'Makefile должен содержать твою систему сборки.')


def layout(lab):
    makefile(lab)
    for root in ('src','include','tests','bench','stages'):
        base = local(lab,root)
        for parent, dirs, names in os.walk(base,followlinks=False):
            for name in dirs+names:
                path = Path(parent)/name
                need(not path.is_symlink(), f'{path.relative_to(lab)}: убери ссылку из дерева исходников.')
            for name in names:
                rel = (Path(parent)/name).relative_to(lab).as_posix()
                data = read(lab,rel)
                need(Path(name).suffix not in ('.o','.d','.a','.so','.i','.s') and
                     not data.startswith((b'\x7fELF',b'!<arch>\n')),
                     f'{rel}: перемести результат сборки в build/, bin/ или lib/.')
    for path in lab.iterdir():
        if path.is_symlink():
            raise Incomplete(f'{path.name}: убери ссылку из корня семинара.')
        if path.is_file():
            raw = read(lab,path.name)
            need(path.suffix not in ('.o','.d','.a','.so','.i','.s') and
                 not raw.startswith((b'\x7fELF',b'!<arch>\n')),
                 f'{path.name}: результат сборки не должен лежать в корне.')


def check(lab, task):
    if task=='s03-001':
        for name in ('build','bin','lib','reports'):
            directory(lab,name)
        sources(lab,include_data=True)
    elif task in ('s03-004','s03-005','s03-010'):
        name = {'s03-004':'gcc','s03-005':'clang','s03-010':'linked'}[task]
        elf(lab,'bin/stages-'+name,(2,3),('main','calculate'))
    elif task=='s03-007':
        preprocessing(lab,'build/stages/stages.i',10)
    elif task in ('s03-008','s03-011'):
        name = 'stages.s' if task=='s03-008' else 'stages-clang.s'
        asm(lab,'build/stages/'+name,'calculate')
    elif task=='s03-009':
        elf(lab,'build/stages/stages.o',(1,),('calculate','main'))
    elif task=='s03-013':
        preprocessing(lab,'build/stages/stages.i',10)
        preprocessing(lab,'build/stages/scale3.i',3)
        same(lab,'stages/include/config.h')
    elif task=='s03-014':
        elf(lab,'bin/textstat-full',(2,3),LIB_SYMBOLS|{'main'})
    elif task=='s03-015':
        same(lab,'data/small.txt')
        data = (MODULE/'assets/code/data/small.txt').read_bytes()
        words = data.split()
        counts = {'File':'data/small.txt','Lines':str(data.count(b'\n')),
                  'Words':str(len(words)), 'Characters':str(len(data)),
                  'Longest word':str(max(map(len,words))), 'Policy':'balanced'}
        counts['Score'] = str(len(words)+10*data.count(b'\n')+max(map(len,words)))
        lines = text(lab,'reports/textstat-small.txt').splitlines()
        expected = [f'{key}: {value}' for key,value in counts.items()]
        need(lines==expected,
             'reports/textstat-small.txt: ожидается stdout исходного textstat для data/small.txt с balanced; проверь поля отчёта.')
    elif task=='s03-016':
        for name,symbol in SYMBOLS.items():
            elf(lab,f'build/separate/{name}.o',(1,),(symbol,))
        elf(lab,'bin/textstat-separate',(2,3),LIB_SYMBOLS|{'main'})
    elif task=='s03-018':
        for level in range(4):
            elf(lab,f'bin/bench-O{level}',(2,3),('main',))
    elif task=='s03-020':
        for level in (0,3):
            asm(lab,f'build/bench/benchmark-O{level}.s','main')
    elif task=='s03-022':
        archive(lab)
    elif task=='s03-023':
        result = elf(lab,'bin/textstat-static',(2,3),LIB_SYMBOLS|{'main'})
        need('libtextstat.so' not in result.needed(),
             'textstat-static не должен зависеть от libtextstat.so; укажи lib/libtextstat.a явно.')
    elif task=='s03-025':
        elf(lab,'lib/libtextstat.so',(3,),LIB_SYMBOLS,dynamic=True)
    elif task=='s03-026':
        result = elf(lab,'bin/textstat-shared',(2,3),('main',))
        need('libtextstat.so' in result.needed(),
             'textstat-shared: нет NEEDED libtextstat.so; проверь выбор .so при линковке.')
    elif task=='s03-030':
        sources(lab)
    elif task=='s03-036':
        headers = {'main':('stats.h','policy.h','formatter.h','textstat.h'),
                   'stats':('stats.h','tokenizer.h','textstat.h'),
                   'tokenizer':('tokenizer.h','textstat.h'),
                   'formatter':('formatter.h','textstat.h'),
                   'policy':('policy.h','textstat.h')}
        for name, includes in headers.items():
            content = text(lab,f'build/deps/{name}.d').replace('\\\n',' ')
            first = content.split('\n\n')[0].split(':',1)
            need(len(first)==2 and re.search(r'(^|[ /])'+name+r'\.o\s*$',first[0]),
                 f'{name}.d: ожидается правило зависимости объекта {name}.o.')
            # Only prerequisites of the object rule, not following -MP dummy rules.
            deps = first[1].splitlines()[0].split()
            required = {f'src/{name}.c'} | {'include/'+h for h in includes}
            need(required <= set(deps), f'{name}.d: нет исходника или нужных заголовков в зависимостях объекта.')
    elif task=='s03-042':
        for name in ('tokenizer','stats','policy'):
            same(lab,f'tests/test_{name}.c')
            elf(lab,f'bin/tests/test_{name}',(2,3),('main',))
    elif task=='s03-045':
        layout(lab)
    elif task=='s03-047':
        sources(lab,include_data=True)
        makefile(lab)
        need(bool(text(lab,'reports/final.txt').strip()), 'Запиши итоговую проверку в reports/final.txt.')
    else:
        raise ValueError(f'Для {task} нет автопроверки; исследовательские шаги отмечаются learn done.')
    print('Проверяемые файлы соответствуют заданию. Программы и Makefile не запускались.')


def setup(lab):
    if hasattr(os,'geteuid') and os.geteuid()==0:
        raise ValueError('Запускай семинар обычным пользователем, без sudo.')
    lab.mkdir(parents=True,exist_ok=True)
    copied = 0
    candidates = [(p,p.relative_to(MODULE/'assets/code'))
                  for p in sorted((MODULE/'assets/code').rglob('*')) if p.is_file()]
    candidates += [(p,Path('.original')/p.relative_to(MODULE/'assets/code'))
                   for p in sorted((MODULE/'assets/code').rglob('*'))
                   if p.is_file() and p.suffix in ('.c','.h')]
    candidates += [(MODULE/'assets/README-ALEDU.md',Path('README-ALEDU.md'))]
    # Validate the complete destination set before the first write.
    for source,relative in candidates:
        destination = local(lab,relative)
        for parent in destination.parents:
            if parent==lab:
                break
            need(not parent.exists() or parent.is_dir(),f'{parent}: ожидался каталог.')
        need(not destination.exists() or destination.is_file(), f'{relative}: ожидался файл.')
    for source,relative in candidates:
        destination = local(lab,relative)
        destination.parent.mkdir(parents=True,exist_ok=True)
        try:
            # Exclusive create preserves even empty or edited student files.
            with destination.open('xb') as target:
                target.write(source.read_bytes())
            copied += 1
        except FileExistsError:
            pass
    print(f'Семинар 3 готов. Добавлено файлов: {copied}; существующая работа сохранена.')


def main():
    if len(sys.argv)<3 or sys.argv[1] not in ('setup','check'):
        raise ValueError('Ожидались setup КАТАЛОГ или check КАТАЛОГ ID.')
    action, raw = sys.argv[1:3]
    if len(sys.argv)!=(3 if action=='setup' else 4):
        raise ValueError('Неверное число аргументов.')
    lab = Path(raw)
    expected = Path(os.environ['HOME'])/'seminar3'
    if not lab.is_absolute() or lab!=expected or lab.is_symlink():
        raise ValueError('Ожидался обычный каталог $HOME/seminar3.')
    if action=='setup':
        setup(lab)
    else:
        definition = json.loads((MODULE/'lesson.json').read_text(encoding='utf-8'))
        known = {t['id']:t['mode'] for t in definition['tasks']}
        if known.get(sys.argv[3])!='auto':
            raise ValueError('Неизвестный ID или шаг с самостоятельной проверкой.')
        check(lab,sys.argv[3])


if __name__=='__main__':
    try:
        main()
    except Incomplete as error:
        print(error)
        sys.exit(1)
    except (OSError,ValueError,KeyError,struct.error) as error:
        print(f'Ошибка проверки/подготовки: {error}',file=sys.stderr)
        sys.exit(2)
