#!/bin/bash
set -euo pipefail
module_dir="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
exec python3 /usr/share/aledu-learn/lesson-tool.py check "$module_dir" "$@"
